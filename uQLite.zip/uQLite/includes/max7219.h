/*******************************************************************************
** File:        max7219.h
** Description:	
**              
** Copyright 2015 Embedded Lab Design - ALL RIGHTS RESERVED.
**
*******************************************************************************/
#ifndef __MAX7219_H__
#define __MAX7219_H__

/*******************************************************************************
**																			  **
**  							DEFINITIONS									  **	
**																			  **
*******************************************************************************/
#define MAX7219_REG_NOOP           (0x00)
#define MAX7219_REG_DIG0           (0x01)
#define MAX7219_REG_DIG1           (0x02)
#define MAX7219_REG_DIG2           (0x03)
#define MAX7219_REG_DIG3           (0x04)
#define MAX7219_REG_DIG4           (0x05)
#define MAX7219_REG_DIG5           (0x06)
#define MAX7219_REG_DIG6           (0x07)
#define MAX7219_REG_DIG7           (0x08)
#define MAX7219_REG_DECODEMODE     (0x09)
#define MAX7219_REG_INTENSITY      (0x0A)
#define MAX7219_REG_SCANLIMIT      (0x0B)
#define MAX7219_REG_SHUTDOWN       (0x0C)
#define MAX7219_REG_DISPLAYTEST    (0x0F)

#define MAX7219_MAXROWS            (2)
#define MAX7219_ROW0			   (0)
#define MAX7219_ROW1			   (1)

#define MAX7219_ROW0_COUNTER	   (MAX7219_REG_DIG3)
#define MAX7219_ROW0_CUSTOMER_DIG2 (MAX7219_REG_DIG0)
#define MAX7219_ROW0_CUSTOMER_DIG1 (MAX7219_REG_DIG1)
#define MAX7219_ROW0_CUSTOMER_DIG0 (MAX7219_REG_DIG2)

#define MAX7219_ROW1_COUNTER	   (MAX7219_REG_DIG3)
#define MAX7219_ROW1_CUSTOMER_DIG2 (MAX7219_REG_DIG2)
#define MAX7219_ROW1_CUSTOMER_DIG1 (MAX7219_REG_DIG1)
#define MAX7219_ROW1_CUSTOMER_DIG0 (MAX7219_REG_DIG0)

#define MAX7219_DUMMY_DATA         (0)
#define MAX7219_DATA_SIZE          (2)

// Error Display Message
#define MAX7219_DEFAULT             '0'
#define MAX7219_START               ':'
#define MAX7219_BLANK				0x0F

// Blinking Timeout
#define MAX7219_BLINK_TIMEOUT       (50)      
#define MAX7219_BLINK_COUNT         (2)

#define MAX7219_ROWLEN              (4)
#define MAX7219_ROWCOUNT            (1)     // BUSTOS: 1 row only; DIPOLOG: 2 rows

/*******************************************************************************
**																			  **
**  					      FUNCTION PROTOTYPES							  **	
**																			  **
*******************************************************************************/
VOID Max7219Init        (VOID);
VOID Max7219Set         (INT8 cRegister, INT8 cData);
VOID Max7219Display     (INT8 *pData,    BOOL bTicket);
VOID Max7219DisplayBlink(VOID);
VOID Max7219DisplayError(UINT8 ucError);

#endif
/*************************************************************** End of File **/