/***************************************************************************//**
 *  \addtogroup BSP_Z8F6482
 *  \{
 *  \file z8uart.h
 *  \brief UART Peripheral Routines
 *  \version 1.0.0
 *  \date 01 July 2015
 *  \author MBordador
 *  
 *  Copyright (C) 2015 Embedded Lab Design\n
 *  All Rights Reserved
*******************************************************************************/
#ifndef __Z8UART_H__
#define __Z8UART_H__

#include <defines.h>

typedef struct
{
    UINT32 ulBaud;
    UINT8 ucParity;
    UINT8 ucStopBits;
    UINT8 ucPriority;
    VOID (*rxCallback)(UINT8 ucData);
    VOID (*txCallback)(VOID);
}stUARTConfig;

VOID UART_Init(UINT8 ucCh);
VOID UART_ForceTx(UINT8 ucCh);
VOID UART_DisableIsr(UINT8 ucCh, BOOL bRxIsr, BOOL bTxIsr);
VOID UART_EnableIsr(UINT8 ucCh, BOOL bRxIsr, BOOL bTxIsr);

#endif // __Z8UART_H__
// End of file