#ifndef __EXTRTC_H__
#define __EXTRTC_H__

#include <defines.h>
#define CENTURY         (2000)


//! Time Structure
typedef struct
{
    UINT8 ucHour;   //!< Hour
    UINT8 ucMinute; //!< Minute
    UINT8 ucSecond; //!< Second
}tTime;

//! Date Structure
typedef struct
{
    UINT8 ucDayOfWeek;  //!< Day of Week
    UINT8 ucDayOfMonth; //!< Day of Month
    UINT8 ucMonth;      //!< Month
    UINT8 ucYear;       //!< Year
}tDate;

//! Date & Time Structure
typedef struct
{
    tDate Date;        //!< Date
    tTime Time;        //!< Time
}tDateTime;


#define MONDAY					1
#define TUESDAY					2
#define WEDNESDAY				3	
#define THURSDAY				4
#define FRIDAY					5
#define SATURDAY				6
#define SUNDAY					7

VOID EXTRTC_SetTime(UINT8 ucHours, UINT8 ucMinutes, UINT8 ucSeconds);  
VOID EXTRTC_SetDate(UINT8 ucDay, UINT8 ucMonth, UINT8 ucDate, UINT8 ucYear);
tTime EXTRTC_GetTime (VOID);
tDate EXTRTC_GetDate (VOID);
tDateTime EXTRTC_GetDateTime (VOID);
UINT32 EXTRTC_GetDateTimeCompact(VOID);
UINT32 DateTimeToUlong(tDateTime dt);
UINT8 EXTRTC_DateTimeToString(CHAR ucFormat, CHAR *cBuff, tDateTime tDT);

#endif // __EXTRTC_H__