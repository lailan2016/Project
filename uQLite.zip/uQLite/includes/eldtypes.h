/***************************************************************************//**
 *  \addtogroup BSP_Z8F6482
 *  \{
 *  \file eldtypes.h
 *  \brief Custom generic data types.
 *  \version 1.0.0
 *  \date 01 July 2015
 *  \author MBordador
 *  
 *  Copyright (C) 2015 Embedded Lab Design\n
 *  All Rights Reserved
*******************************************************************************/
#ifndef __ELD_TYPES_H__
#define __ELD_TYPES_H__

#include <defines.h>

#define nullstr_t		('\0')
#define nullptr_t 		((void *)0)

#define BIT0            (0x01)
#define BIT1            (0x02)
#define BIT2            (0x04)
#define BIT3            (0x08)
#define BIT4            (0x10)
#define BIT5            (0x20)
#define BIT6            (0x40)
#define BIT7            (0x80)


#define MHz             *1e6
#define KHz             *1e3
#define Hz              *1

//! \}
#endif // __ELD_TYPES_H__