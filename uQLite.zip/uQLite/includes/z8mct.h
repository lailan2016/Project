/***************************************************************************//**
 *  \addtogroup BSP_Z8F6482
 *  \{
 *  \file z8mct.h
 *  \brief Application timer routines using the Multi-Channel Timer Peripheral.
 *  \version 1.0.0
 *  \date 01 July 2015
 *  \author MBordador
 *  
 *  Copyright (C) 2015 Embedded Lab Design\n
 *  All Rights Reserved
*******************************************************************************/
#ifndef __MCT_H__
#define __MCT_H__

typedef struct
{
    BOOL isRunning;
    UINT16 ulDuration;
    UINT16 ulCount;
}stMCTimers;


typedef struct
{
    UINT8 ucNumTimers;
    UINT16 ulInterval;
    UINT8 ucPrescale;
    UINT8 ucPriority;
    VOID (*fxCallback)(VOID);
}stMCTConfig;

/***************************************************************************//**
 *  \fn VOID MCT_Init(UINT32 ulInterval, UINT8 ucPriority)
 *  \brief Initializes the MCT peripheral
 *  \param ulInterval - timer interval, in milliseconds
 *  \param ucPriority - timer interrupt priority
*******************************************************************************/
VOID MCT_Init(VOID);
              
/***************************************************************************//**
 *  \fn UINT8 MCT_AddTimer(UINT32 ulDuration)
 *  \brief Adds a timer "sub-channel" with the specified duration
 *   Actual time is calculated by \f$(interval * duration)\f$ \n
 *   where:
 *   - \b interval - timer interval set in MCT_Init() \n
 *   - \b duration - timer duration set in MCT_AddTimer()
 *  \param ulDuration - timer duration, in milliseconds
 *  \returns UINT8 - timer "sub-channel" number allocated with the specified duration.
 *  \returns 0 - if no timer "sub-channel" is allocated
*******************************************************************************/
UINT8 MCT_AddTimer(UINT16 ulDuration);

/***************************************************************************//**
 *  \fn VOID MCT_StartTimer(UINT8 ucTmrChannel)
 *  \brief Starts the specified timer "sub-channel"
 *  \param ucTmrChannel - timer "sub-channel" to start
*******************************************************************************/
VOID MCT_StartTimer(UINT8 ucTmrChannel);

BOOL MCT_IsStarted(UINT8 ucTmrChannel);

/***************************************************************************//**
 *  \fn VOID MCT_StopTimer(UINT8 ucTmrChannel)
 *  \brief Stops the specified timer "sub-channel"
 *  \param ucTmrChannel - timer "sub-channel" to stop
*******************************************************************************/
VOID MCT_StopTimer(UINT8 ucTmrChannel);

/***************************************************************************//**
 *  \fn VOID bMCT_IsTimeout(UINT8 ucTmrChannel)
 *  \brief Checks if the specified timer "sub-channel" is finished counting. 
 *   Also restarts the timer if a timeout event is detected.
 *  \returns TRUE - timeout event occurred, and timer is restarted
 *  \returns FALSE - no timeout event
*******************************************************************************/
BOOL bMCT_IsTimeout(UINT8 ucTmrChannel);
//! \}
#endif //__MCT_H__