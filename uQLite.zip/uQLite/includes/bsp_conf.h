#ifndef __BSP_CONFIG_H__
#define __BSP_CONFIG_H__

////////////////////////////////////////////////////////////////////////////////
// MCT Settings
////////////////////////////////////////////////////////////////////////////////
#define MCT_PRESCALE_1      (0)
#define MCT_PRESCALE_2      (1)
#define MCT_PRESCALE_4      (2)
#define MCT_PRESCALE_8      (3)
#define MCT_PRESCALE_16     (4)
#define MCT_PRESCALE_32     (5)
#define MCT_PRESCALE_64     (6)
#define MCT_PRESCALE_128    (7)

////////////////////////////////////////////////////////////////////////////////
// UART Settings
////////////////////////////////////////////////////////////////////////////////
//! \name UART Channel Definitions
#define UART0               (0)
#define UART1               (1)

//! \name Parity Selections
#define NOPARITY        (0x00)
#define EVPARITY        (0x10)
#define ODPARITY        (0x18)

//! \name Stopbit Selections
#define STOP_1          (0x00)
#define STOP_2          (0x02)

//! \name Baudrate Selections
#define BAUD_9600       9600UL
#define BAUD_19200		19200UL
#define BAUD_38400		38400UL
#define BAUD_57600		57600UL
#define BAUD_115200		115200UL

////////////////////////////////////////////////////////////////////////////////
// RTC Settings
////////////////////////////////////////////////////////////////////////////////
#define RTC_PRESCALE_1          (0)
#define RTC_PRESCALE_2          (1)
#define RTC_PRESCALE_4          (2)
#define RTC_PRESCALE_8          (3)
#define RTC_PRESCALE_16         (4)
#define RTC_PRESCALE_32         (5)
#define RTC_PRESCALE_64         (6)
#define RTC_PRESCALE_128        (7)

#define RTC_FREQ_32kHz          (0)
#define RTC_FREQ_60HzPower      (1)
#define RTC_FREQ_50HzPower      (2)
#define RTC_FREQ_UsePrescale    (3)

#define RTC_CLK_PCLK            (0)
#define RTC_CLK_WTO             (1)
#define RTC_CLK_SYSCLK          (2)
#define RTC_CLK_EVENT           (3)

////////////////////////////////////////////////////////////////////////////////
// SPI Settings
////////////////////////////////////////////////////////////////////////////////
#define ESPI0                       (0)
#define ESPI1                       (1)

#define SPI_DIRECTION_DISABLE       (0x00)
#define SPI_DIRECTION_RXONLY        (0x01)
#define SPI_DIRECTION_TXONLY        (0x40)
#define SPI_DIRECTION_RXTX          (0x41)

#define SPI_TXER_MODE0              (0x00)  // 0        0       falling     rising      low      
#define SPI_TXER_MODE1              (0x08)  // 0        1       rising      falling     high
#define SPI_TXER_MODE2              (0x10)  // 1        0       rising      falling     low
#define SPI_TXER_MODE3              (0x18)  // 1        1       falling     rising      high

#define SPI_MODE_MASTER             (0x02)
#define SPI_MODE_SLAVE              (0x00)


#endif  // __BSP_CONFIG_H__