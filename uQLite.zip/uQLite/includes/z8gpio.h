/***************************************************************************//**
 *  \addtogroup BSP_Z8F6482
 *  \{
 *  \file z8gpio.h
 *  \brief General Purpose I/O Routines
 *  \version 1.0.0
 *  \date 01 July 2015
 *  \author MBordador
 *  
 *  Copyright (C) 2015 Embedded Lab Design\n
 *  All Rights Reserved
*******************************************************************************/
#ifndef __Z8GPIO_H__
#define __Z8GPIO_H__

//! \name GPIO Mode Selection
//! \{
#define GPIO_INPUT      (FALSE)
#define GPIO_OUTPUT     (TRUE)
//! \}

/***************************************************************************//**
 *  \fn BOOL GPIO_SetPort(UINT8 ucPort, UINT8 ucBits, BOOL bIsOutput)
 *  \brief Sets the specified GPIO port bit to either input or output
 *  \param ucPort - port to set
 *  \param ucBits - port bit/s to set
 *  \param bIsOutput - TRUE, if setting the specified port bit as output. FALSE, otherwise.
 *  \returns TRUE - if port bit is set correctly
 *  \returns FALSE - the specified port and/or port bit is not supported
*******************************************************************************/
BOOL GPIO_SetPort(UINT8 ucPort, UINT8 ucBits, BOOL bIsOutput);

/***************************************************************************//**
 *  \fn BOOL GPIO_SetPortInterrupt(UINT8 ucPort, UINT8 ucBits, UINT8 ucPriority)
 *  \brief Sets the specified GPIO port bit to an input interrupt.
 *  \param ucPort - port to set
 *  \param ucBits - port bit/s to set
 *  \param ucPriority - port input interrupt priority
 *  \returns TRUE - if port bit is set correctly
 *  \returns FALSE - the specified port and/or port bit is not supported
 *  \todo Port interrupt routine/s not yet implemented
*******************************************************************************/
BOOL GPIO_SetPortInterrupt(UINT8 ucPort, UINT8 ucBits, UINT8 ucPriority);

/***************************************************************************//**
 *  \fn UINT8 GPIO_ReadPort(UINT8 ucPort)
 *  \brief Reads the specified port
 *  \param ucPort - port to read
 *  \returns UINT8 - value read from the specified port
*******************************************************************************/
UINT8 GPIO_ReadPort(UINT8 ucPort);

//! \}
#endif // __Z8GPIO_H__
// End of file