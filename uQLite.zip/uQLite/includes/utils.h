#ifndef __UTILS_H__
#define __UTILS_H__


UINT8 u_strcpy(CHAR *src, CHAR *dest);
UINT8 u_strcpy_rom2ram(rom CHAR *src, CHAR *dest);
UINT8 u_strcpy_rom2ram_len(rom CHAR *src, CHAR *dest, UINT8 maxlen);

BOOL u_strcmp(CHAR *s1, CHAR *s2);
BOOL u_memcmp(UINT8 *src, UINT8 *dest, UINT16 len);

VOID *u_memcpy(UINT8 *src, UINT8 *dest, UINT16 len);
VOID *u_memcpy_rom2ram(rom UINT8 *src, UINT8 *dest, UINT16 len);

CHAR *u_chr(CHAR *src, CHAR cChr);
CHAR *u_trim(CHAR *src);

VOID u_itoa(CHAR *dest, UINT8 len, UINT16 val);
UINT8 u_itod(CHAR *dest, UINT16 val);

UINT16 u_atoi(CHAR *src, UINT8 len);


#endif // __UTILS_H__
// End of file