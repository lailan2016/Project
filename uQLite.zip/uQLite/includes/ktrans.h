#ifndef __KTRANS_H__
#define __KTRANS_H__

#include "eldtypes.h"
#include "rtc.h"
#include "main.h"

#define TKTSTAT_NEW     (0)     // initial ticket status
#define TKTSTAT_WAIT    (1)     // WAITING (issued by clicker)
#define TKTSTAT_HOLD    (2)     // HOLD (issued by clicker)
#define TKTSTAT_TXER    (3)     // TRANSFER (issued by clicker)
#define TKTSTAT_PROC    (4)     // CALL/RECALL (issued by clicker)
#define TKTSTAT_DONE    (5)     // DONE (issued by clicker)

typedef struct
{
    // Values assigned on ticket creation
    UINT16 uiTicketNum;     // Ticket Number
    UINT8 ucSvcIdx;         // Determines Service Name: cSvcList[ucSvcIdx]
    tDateTime stStaTime;    // Date & Time the ticket is issued
    
    // Values assigned during ticket processing
    UINT8 ucCallerNum;      // Window number assigned to caller device
    
    // Values assigned on ticket closing/saving to logs
    UINT8 ucRmksIdx;        // Determines Remarks: cRmksList[ucRmksIdx]
//    stDateTime stEndTime;   // Date & Time the ticket status switched to DONE
}tTKTInfo;

// Special value for ucRmksIdx to indicate "Transferred"
#define TKTREMARKS_TXER     (0xFF)

VOID KTRANS_Init(VOID);
VOID KTRANS_GenerateTicket(UINT8 ucSvcIdx);
VOID KTRANS_ProcTicketRqst(VOID);

// ticket.c
//VOID TKT_Init(VOID);
VOID TKT_PrintHeader(VOID);
VOID TKT_Print(tTKTInfo tInfo);
VOID TKT_PrintErr(UINT16 err, CHAR *acStr);
VOID TKT_PrintOnline(VOID);

#endif // __KTRANS_H__