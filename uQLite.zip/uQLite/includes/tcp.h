#ifndef __TCP_H__
#define __TCP_H__

////////////////////////////////////////////////////////////////////////////////
// TCP Communications Protocol
////////////////////////////////////////////////////////////////////////////////
#define RQSTMSG_LEN             (23)
#define RESPMSG_LEN             (21)

#define TCP_TKTNUM_LEN          (4)
#define TCP_DVCID_LEN           (DVCID_LEN)
#define TCP_TIME_LEN            (8)
#define TCP_RMKS_LEN            (2)
#define TCP_SVCIDX_LEN          (2)
#define TCP_RQSTID_LEN          (1)

#define TCP_SEND_RETRIES        (3)

#define TCP_PROT_SEPARATOR       ','
#define TCP_PROT_EOF             '\n'
#define TCP_PROT_SOF             '!'

// Request IDs
#define TCP_RQSTID_CALL         ('1')
#define TCP_RQSTID_SKIP         ('2')
#define TCP_RQSTID_DONE         ('3')
#define TCP_RQSTID_DISPLAY      ('4')
#define TCP_RQSTID_TXER         ('5')
#define TCP_RQSTID_PUTHOLD      ('6')
#define TCP_RQSTID_CALLHOLD     ('7')

#define TCP_RQSTID_MINVAL       (TCP_RQSTID_CALL)
#define TCP_RQSTID_MAXVAL       (TCP_RQSTID_CALLHOLD)


typedef struct
{
    CHAR FromDeviceHeader;
    UINT16 FromDeviceId;
    
    CHAR ToDeviceHeader;
    UINT16 ToDeviceId;
    
    CHAR RequestId;
    CHAR TicketNumber[TCP_TKTNUM_LEN];
    UINT8 Remarks;
}TcpRequest;

typedef struct
{
    CHAR FromDeviceHeader;
    UINT16 FromDeviceId;
    
    CHAR ToDeviceHeader;
    UINT16 ToDeviceId;
    
    UINT8 ServiceIdx;
    CHAR TicketNum[TCP_TKTNUM_LEN];
}TcpResponse;

#endif
// End of file