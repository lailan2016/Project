/***************************************************************************//**
 *  \addtogroup BSP_Z8F6482
 *  \{
 *  \file z8spi.h
 *  \brief SPI Peripheral Routines
 *  \version 1.0.0
 *  \date 01 July 2015
 *  \author MBordador
 *  
 *  Copyright (C) 2015 Embedded Lab Design\n
 *  All Rights Reserved
*******************************************************************************/
#ifndef __SPI_H__
#define __SPI_H__

#include "eldtypes.h"

typedef struct
{
    UINT8 ucCtl0;
    UINT8 ucPriority;
    CHAR cSsPort;
    UINT8 ucSsPortBit;
    VOID(*rxCallback)(UINT8 ucData);
    VOID (*txCallback)(VOID);
}stSPIConfig;

#define SPI_MAXBAUD                 (_DEFFREQ / 2)

#define SPI_DIRECTION_MASK          (0x41)
#define SPI_TXERMODE_MASK           (0x18)
#define SPI_MODE_MASK               (0x02)

/***************************************************************************//**
 *  \fn VOID SPI_Init(UINT8 ucCh, UINT8 ucDir, UINT8 ucTxerMode, UINT8 ucMode, UINT8 etPriority, UINT8 ucPort, UINT8 ucPortBit);
 *  \brief Initializes the SPI peripheral
 *  \param ucCh - SPI channel to initialize
 *  \param ucDir - SPI direction
 *  \param ucTxerMode - SPI transfer mode
 *  \param ucMode - SPI mode
 *  \param etPriority - interrupt priority of the specified SPI channel
 *  \param ucPort - SS port used
 *  \param ucPortBit - SS port bit used
 *  \todo Remove SS port bit in the parameter list. Use defines in mcu_conf.h instead
*******************************************************************************/
VOID SPI_Init      (UINT8 ucCh);

/***************************************************************************//**
 *  \fn VOID SPI_SetSlaveSelect(UINT8 ucCh, UINT8 ucPort, UINT8 ucPortBit)
 *  \brief Sets up the specified port and port bit as SS pin of the specified SPI channel
 *  \param ucCh - SPI channel
 *  \param ucPort - SS port used
 *  \param ucPortBit - SS port bit used
*******************************************************************************/
VOID SPI_SetSlaveSelect(UINT8 ucCh,
                    UINT8 ucPort, 
                    UINT8 ucPortBit);
                    
/***************************************************************************//**
 *  \fn VOID SPI_SetBaud(UINT8 ucCh, UINT32 ulBaud)
 *  \brief Sets the baudrate of the specified SPI channel
 *  \param ucCh - SPI channel
 *  \param ulBaud - baudrate to set
*******************************************************************************/
VOID SPI_SetBaud   (UINT8 ucCh,
                    UINT32 ulBaud);

/***************************************************************************//**
 *  \fn VOID SPI_SendByte(UINT8 ucCh, UINT8 ucData)
 *  \brief Transmits a byte to the specified SPI channel
 *  \param ucCh - SPI channel
 *  \param ucData - data byte to transmit
*******************************************************************************/
VOID SPI_SendByte  (UINT8 ucCh,
                    UINT8 ucData);

/***************************************************************************//**
 *  \fn UINT8 SPI_ReceiveByte(UINT8 ucCh)
 *  \brief Receive a byte from the specified SPI channel
 *  \param ucCh - SPI channel
 *  \returns UINT8 - data byte received
*******************************************************************************/
UINT8 SPI_ReceiveByte(UINT8 ucCh);

/***************************************************************************//**
 *  \fn SPI_Assert(UINT8 ucCh)
 *  \brief Asserts the SS pin of the specified SPI channel
 *  \param ucCh - SPI channel
*******************************************************************************/
VOID SPI_Assert     (UINT8 ucCh);

/***************************************************************************//**
 *  \fn SPI_Deassert(UINT8 ucCh)
 *  \brief Deasserts the SS pin of the specified SPI channel
 *  \param ucCh - SPI channel
*******************************************************************************/
VOID SPI_Deassert   (UINT8 ucCh);
//! \}
#endif // __SPI_H__
// End of file