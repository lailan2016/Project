/***************************************************************************//**
 *  \addtogroup BSP_Z8F6482
 *  \{
 *  \file z8rtc.h
 *  \brief RTC Peripheral Routines
 *  \version 1.0.0
 *  \date 01 July 2015
 *  \author MBordador
 *  
 *  Copyright (C) 2015 Embedded Lab Design\n
 *  All Rights Reserved
*******************************************************************************/
#ifndef __RTC_H__
#define __RTC_H__

#include <defines.h>

#define CENTURY         (2000)

typedef struct
{
    UINT8 ucPrescale;
    UINT8 ucFreqSel;
    UINT8 ucClkSel;
}stRTCConfig;


//! \name RTC Mode Selection
//! \{
#define CALENDAR           (0)
#define COUNTER            (1)
//! \}

//! Time Structure
typedef struct
{
    UINT8 ucHour;   //!< Hour
    UINT8 ucMinute; //!< Minute
    UINT8 ucSecond; //!< Second
}stTime;

//! Date Structure
typedef struct
{
    UINT8 ucDayOfWeek;  //!< Day of Week
    UINT8 ucDayOfMonth; //!< Day of Month
    UINT8 ucMonth;      //!< Month
    UINT8 ucYear;       //!< Year
}stDate;

//! Date & Time Structure
typedef struct
{
    stDate Date;        //!< Date
    stTime Time;        //!< Time
}stDateTime;

/***************************************************************************//**
 *  \fn VOID RTC_Init(UINT8 ucMode, UINT8 bBCD, UINT8 bDST)
 *  \brief Initializes the RTC peripheral
 *  \param ucMode - Calendar or Counter mode
 *  \param bBCD -
 *  \param bDST - 
*******************************************************************************/
VOID RTC_Init   (UINT8 ucMode,
                 UINT8 bBCD,
                 UINT8 bDST);

/***************************************************************************//**
 *  \fn VOID RTC_SetTime(UINT8 ucHours, UINT8 ucMinutes, UINT8 ucSeconds)
 *  \brief Sets the RTC time with the specified time
 *  \param ucHours - Hour time
 *  \param ucMinutes - Minute time
 *  \param ucSeconds - Second time
*******************************************************************************/
VOID RTC_SetTime(UINT8 ucHours,
                 UINT8 ucMinutes,
                 UINT8 ucSeconds);  
                 
/***************************************************************************//**
 *  \fn VOID RTC_SetDate(UINT8 ucDay, UINT8 ucMonth, UINT8 ucDate, UINT8 ucYear)
 *  \brief Sets the RTC date with the specified time
 *  \param ucDay - day of week
 *  \param ucMonth - month
 *  \param ucDate - date
 *  \param ucYear - year
*******************************************************************************/
VOID RTC_SetDate(UINT8 ucDay,
                 UINT8 ucMonth,
                 UINT8 ucDate,
                 UINT8 ucYear);
                 
/***************************************************************************//**
 *  \fn stTime RTC_ReadTime(VOID)
 *  \brief Reads the RTC time
 *  \returns stTime - RTC time
*******************************************************************************/
stTime RTC_ReadTime (VOID);

/***************************************************************************//**
 *  \fn stDate RTC_ReadDate(VOID)
 *  \brief Reads the RTC date
 *  \returns stDate - RTC date
*******************************************************************************/
stDate RTC_ReadDate (VOID);

/***************************************************************************//**
 *  \fn stDateTime RTC_ReadDateTime(VOID)
 *  \brief Reads the RTC date & time
 *  \returns stDateTime - RTC date & time
*******************************************************************************/
stDateTime RTC_ReadDateTime (VOID);

/***************************************************************************//**
 *  \fn VOID RTC_SetCalendarAlarmData(UINT8 ucDay, UINT8 ucDate, UINT8 ucHours, UINT8 ucMinutes, UINT8 ucSeconds)
 *  \brief Sets an RTC alarm
 *  \param ucDay - day of week of alarm
 *  \param ucDate - date of alarm
 *  \param ucHours - hour time of alarm
 *  \param ucMinutes - minutes time of alarm
 *  \param ucSeconds - seconds time of alarm
*******************************************************************************/
VOID RTC_SetCalendarAlarmData   (UINT8 ucDay,
                                 UINT8 ucDate, 
                                 UINT8 ucHours,
                                 UINT8 ucMinutes,
                                 UINT8 ucSeconds);

/***************************************************************************//**
 *  \fn VOID RTC_SetCalendarAlarmConfig (UINT8 bDOMEnable, UINT8 bDOWEnable, UINT8 bHoursEnable, UINT8 bMinutesEnable, UINT8 bSecondsEnable)
 *  \brief Enables an RTC alarm
 *  \param bDOMEnable - 
 *  \param bDOWEnable - 
 *  \param bHoursEnable - 
 *  \param bMinutesEnable - 
 *  \param bSecondsEnable - 
*******************************************************************************/
VOID RTC_SetCalendarAlarmConfig (UINT8 bDOMEnable,
                                 UINT8 bDOWEnable,
                                 UINT8 bHoursEnable,
                                 UINT8 bMinutesEnable,
                                 UINT8 bSecondsEnable);
                 
/***************************************************************************//**
 *  \fn VOID RTC_SetCounter(UINT32 ucCount)
 *  \brief Sets RTC counter mode
 *  \param ucCount - 
*******************************************************************************/
VOID     RTC_SetCounter  (UINT32 ucCount);

/***************************************************************************//**
 *  \fn UINT32 RTC_ReadCounter (VOID)
 *  \brief Reads RTC count value
 *  \returns UINT32 - RTC count value
*******************************************************************************/
UINT32   RTC_ReadCounter (VOID);

/***************************************************************************//**
 *  \fn VOID RTC_SetCounterAlarmData(UINT32 ulData)
 *  \brief Sets counter alarm info
 *  \param ulData - counter alarm info
*******************************************************************************/
VOID RTC_SetCounterAlarmData   (UINT32 ulData);

/***************************************************************************//**
 *  \fn VOID RTC_SetCounterAlarmConfig (UINT8 bByte0, UINT8 bByte1, UINT8 bByte2, UINT8 bByte3)
 *  \brief Sets RTC counter alarm configuration
 *  \param bByte0 - 
 *  \param bByte1 - 
 *  \param bByte2 - 
 *  \param bByte3 - 
*******************************************************************************/
VOID RTC_SetCounterAlarmConfig (UINT8 bByte0,
                                UINT8 bByte1,
                                UINT8 bByte2,
                                UINT8 bByte3);

/***************************************************************************//**
 *  \fn UINT8 RTC_DecToBCD(UINT8 ucNumber)
 *  \brief Converts decimal format to BCD format
 *  \param ucNumber - decimal number to convert
 *  \returns UINT8 - BCD value
 *  \todo Move this numeric conversions
*******************************************************************************/
UINT8   RTC_DecToBCD    (UINT8 ucNumber);

/***************************************************************************//**
 *  \fn CHAR *RTC_DateTimeToString(CHAR ucFormat, stDateTime stDT)
 *  \brief Converts the specified date & time to string
 *  \param ucFormat - string format conversion to produce
 *  \param stDT - date & time to convert to string
 *  \returns UINT8 - date & time in string format
*******************************************************************************/
CHAR *RTC_DateTimeToString(CHAR ucFormat, stDateTime *stDT, BOOL bIs24Hour);

//! \}
#endif
// End of file