/*******************************************************************************
** File:        flashloader.h
** Description: This file contains prototypes and macros uses by:
**                  flashloader.c
**                  external_flash.c
**                  ocd_api.c
**                  pcmode.c
**                  
** 
** This project is compiled and tested using ZDS II � Z8 Encore! version 5.2.1
**
** Copyright 2015 Zilog Inc. ALL RIGHTS RESERVED.
*
********************************************************************************
* 
* The source code in this file was written by an authorized Zilog employee or a
* licensed consultant. The source code has been verified to the fullest extent 
* possible.
*
* Permission to use this code is granted on a royalty-free basis. However, 
* users are cautioned to authenticate the code contained herein.
*
* ZILOG DOES NOT GUARANTEE THE VERACITY OF THIS SOFTWARE; ANY SOFTWARE 
* CONTAINED HEREIN IS PROVIDED "AS IS." NO WARRANTIES ARE GIVEN, WHETHER 
* EXPRESS, IMPLIED, OR STATUTORY, INCLUDING IMPLIED WARRANTIES OF FITNESS FOR 
* PARTICULAR PURPOSE OR MERCHANTABILITY. IN NO EVENT WILL ZILOG BE LIABLE FOR 
* ANY SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES OR ANY LIABILITY IN TORT,
* NEGLIGENCE, OR OTHER LIABILITY INCURRED AS A RESULT OF THE USE OF THE 
* SOFTWARE, EVEN IF ZILOG HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. 
* ZILOG ALSO DOES NOT WARRANT THAT THE USE OF THE SOFTWARE, OR OF ANY 
* INFORMATION CONTAINED THEREIN WILL NOT INFRINGE ANY PATENT, COPYRIGHT, OR    
* TRADEMARK OF ANY THIRD PERSON OR ENTITY.

* THE SOFTWARE IS NOT FAULT-TOLERANT AND IS NOT DESIGNED, MANUFACTURED OR 
* INTENDED FOR USE IN CONJUNCTION WITH ON-LINE CONTROL EQUIPMENT, IN HAZARDOUS 
* ENVIRONMENTS, IN APPLICATIONS REQUIRING FAIL-SAFE PERFORMANCE, OR WHERE THE 
* FAILURE OF THE SOFTWARE COULD LEAD DIRECTLY TO DEATH, PERSONAL INJURY OR 
* SEVERE PHYSICAL OR ENVIRONMENTAL DAMAGE (ALL OF THE FOREGOING, "HIGH RISK 
* ACTIVITIES"). ZILOG SPECIFICALLY DISCLAIMS ANY EXPRESS OR IMPLIED WARRANTY TO
* HIGH RISK ACTIVITIES.
*
*******************************************************************************/
#ifndef _FLASHLOADER_H_
#define _FLASHLOADER_H_

#include "eldtypes.h"

////////////////////////////////////////////////////////////////////////////////
// Flashloader Macros
////////////////////////////////////////////////////////////////////////////////
#define FLASH_PAGESHIFT	        9
#define FLASH_LOCK              0x00
#define FLASH_FIRSTUNLOCK       0x73
#define FLASH_SECONDUNLOCK      0x8C
#define FLASH_PAGEERASE         0x95 
#define FLASH_WAITSTAT          0x07
#define FLASH_PAGESIZE          512

////////////////////////////////////////////////////////////////////////////////
// Flashloader Prototypes
////////////////////////////////////////////////////////////////////////////////
VOID FLASH_Write(rom UINT8 *aucStartAddr, UINT8 *aucData, UINT16 uiLen);

#endif

/****************************** end of file ***********************************/
