/***************************************************************************//**
 *  \addtogroup FatFs
 *  \brief Implements file system on an SD Card
 *  \{
 *  \file ff.h
 *  \brief FAT file system module
 *  \version 0.11
 *  \date 2015
 *  \author ChaN
 *  
 *  Copyright (C) 2015, ChaN, all right reserved.
 *
 *  This software is provided by the copyright holder and contributors "AS IS"
 *  and any warranties related to this software are DISCLAIMED.
 *  The copyright owner or contributors be NOT LIABLE for any damages caused
 *  by use of this software.
*******************************************************************************/
#ifndef _FATFS
//! \def _FATFS
//! \brief Revision ID
#define _FATFS	32020

#ifdef __cplusplus
extern "C" {
#endif

#include <defines.h>
#include "ffconf.h"

#if _FATFS != _FFCONF
#error Wrong configuration file (ffconf.h).
#endif

/***************************************************************************//**
 *  \name Definitions of Volume Management
 *  \{
*******************************************************************************/
#if _MULTI_PARTITION
//! \name Multiple partition configuration
//! \{
//! Volume partition
typedef struct {
	UINT8 pd;	//!< Physical drive number
	UINT8 pt;	//!< Partition: 0:Auto detect, 1-4:Forced partition)
} PARTITION;

//! \var VolToPart[]
//! \brief Volume - Partition resolution table
extern PARTITION VolToPart[];

//! \def LD2PD(vol)
//! \brief Get physical drive number
#define LD2PD(vol) (VolToPart[vol].pd)

//! \def LD2PT(vol)
//! \brief Get partition index
#define LD2PT(vol) (VolToPart[vol].pt)
//! \}
#else		
//! \name Single partition configuration
//! \{

//! \def LD2PD(vol)
//! \brief Each logical drive is bound to the same physical drive number
#define LD2PD(vol) (UINT8)(vol)

//! \def LD2PT(vol)
//! \brief Find first valid partition or in SFD
#define LD2PT(vol) 0
//! \}
#endif
//! \}

/***************************************************************************//**
 *  \name Type of path name strings on FatFs API
 *  \{
*******************************************************************************/
#if _LFN_UNICODE
//! \name Unicode string
//! \{
#if !_USE_LFN
#error _LFN_UNICODE must be 0 at non-LFN cfg.
#endif
#ifndef _INC_TCHAR
typedef WCHAR TCHAR;
#define _T(x) L ## x
#define _TEXT(x) L ## x
#endif
//! \}
#else
//! \name ANSI/OEM string
//! \{
#ifndef _INC_TCHAR
typedef char TCHAR;
#define _T(x) x
#define _TEXT(x) x
#endif
//! \}

#endif
//! \}

//! File system object structure (FATFS)
typedef struct {
	UINT8	fs_type;		//!< FAT sub-type (0:Not mounted)
	UINT8	drv;			//!< Physical drive number
	UINT8	csize;			//!< Sectors per cluster (1,2,4...128)
	UINT8	n_fats;			//!< Number of FAT copies (1 or 2)
	UINT8	wflag;			//!< win[] flag (b0:dirty)
	UINT8	fsi_flag;		//!< FSINFO flags (b7:disabled, b0:dirty)
	UINT16	id;				//!< File system mount ID
	UINT16	n_rootdir;		//!< Number of root directory entries (FAT12/16)
#if _MAX_SS != _MIN_SS
	UINT16	ssize;			//!< UINT8s per sector (512, 1024, 2048 or 4096)
#endif
#if _FS_REENTRANT
	_SYNC_t	sobj;			//!< Identifier of sync object
#endif
#if !_FS_READONLY
	UINT32	last_clust;		//!< Last allocated cluster
	UINT32	free_clust;		//!< Number of free clusters
#endif
#if _FS_RPATH
	UINT32	cdir;			//!< Current directory start cluster (0:root)
#endif
	UINT32	n_fatent;		//!< Number of FAT entries, = number of clusters + 2
	UINT32	fsize;			//!< Sectors per FAT
	UINT32	volbase;		//!< Volume start sector
	UINT32	fatbase;		//!< FAT start sector
	UINT32	dirbase;		//!< Root directory start sector (FAT32:Cluster#)
	UINT32	database;		//!< Data start sector
	UINT32	winsect;		//!< Current sector appearing in the win[]
	UINT8	win[_MAX_SS];	//!< Disk access window for Directory, FAT (and file data at tiny cfg)
} FATFS;

//! File object structure (FIL)
typedef struct {
	FATFS*	fs;				//!< Pointer to the related file system object (**do not change order**)
	UINT16	id;				//!< Owner file system mount ID (**do not change order**)
	UINT8	flag;			//!< Status flags
	UINT8	err;			//!< Abort flag (error code)
	UINT32	fptr;			//!< File read/write pointer (Zeroed on file open)
	UINT32	fsize;			//!< File size
	UINT32	sclust;			//!< File start cluster (0:no cluster chain, always 0 when fsize is 0)
	UINT32	clust;			//!< Current cluster of fpter (not valid when fprt is 0)
	UINT32	dsect;			//!< Sector number appearing in buf[] (0:invalid)
#if !_FS_READONLY
	UINT32	dir_sect;		//!< Sector number containing the directory entry
	UINT8*	dir_ptr;		//!< Pointer to the directory entry in the win[]
#endif
#if _USE_FASTSEEK
	UINT32*	cltbl;			//!< Pointer to the cluster link map table (Nulled on file open)
#endif
#if _FS_LOCK
	UINT16	lockid;			//!< File lock ID origin from 1 (index of file semaphore table Files[])
#endif
#if !_FS_TINY
	UINT8	buf[_MAX_SS];	//!< File private data read/write window
#endif
} FIL;

//! Directory object structure (DIR)
typedef struct {
	FATFS*	fs;				//!< Pointer to the owner file system object (**do not change order**)
	UINT16	id;				//!< Owner file system mount ID (**do not change order**)
	UINT16	index;			//!< Current read/write index number
	UINT32	sclust;			//!< Table start cluster (0:Root dir)
	UINT32	clust;			//!< Current cluster
	UINT32	sect;			//!< Current sector
	UINT8*	dir;			//!< Pointer to the current SFN entry in the win[]
	UINT8*	fn;				//!< Pointer to the SFN (in/out) {file[8],ext[3],status[1]}
#if _FS_LOCK
	UINT16	lockid;			//!< File lock ID (index of file semaphore table Files[])
#endif
#if _USE_LFN
	WCHAR*	lfn;			//!< Pointer to the LFN working buffer
	UINT16	lfn_idx;		//!< Last matched LFN index number (0xFFFF:No LFN)
#endif
#if _USE_FIND
	const TCHAR*	pat;	//!< Pointer to the name matching pattern
#endif
} DIR;

//! File information structure (FILINFO)
typedef struct {
	UINT32	fsize;			//!< File size
	UINT16	fdate;			//!< Last modified date
	UINT16	ftime;			//!< Last modified time
	UINT8	fattrib;		//!< Attribute
	TCHAR	fname[13];		//!< Short file name (8.3 format)
#if _USE_LFN
	TCHAR*	lfname;			//!< Pointer to the LFN buffer
	UINT16 	lfsize;			//!< Size of LFN buffer in TCHAR
#endif
} FILINFO;

//! File function return code (FRESULT)
typedef enum {
	FR_OK = 0,				//!< (0) Succeeded
	FR_DISK_ERR,			//!< (1) A hard error occurred in the low level disk I/O layer
	FR_INT_ERR,				//!< (2) Assertion failed
	FR_NOT_READY,			//!< (3) The physical drive cannot work
	FR_NO_FILE,				//!< (4) Could not find the file
	FR_NO_PATH,				//!< (5) Could not find the path
	FR_INVALID_NAME,		//!< (6) The path name format is invalid
	FR_DENIED,				//!< (7) Access denied due to prohibited access or directory full
	FR_EXIST,				//!< (8) Access denied due to prohibited access
	FR_INVALID_OBJECT,		//!< (9) The file/directory object is invalid
	FR_WRITE_PROTECTED,		//!< (10) The physical drive is write protected
	FR_INVALID_DRIVE,		//!< (11) The logical drive number is invalid
	FR_NOT_ENABLED,			//!< (12) The volume has no work area
	FR_NO_FILESYSTEM,		//!< (13) There is no valid FAT volume
	FR_MKFS_ABORTED,		//!< (14) The f_mkfs() aborted due to any parameter error
	FR_TIMEOUT,				//!< (15) Could not get a grant to access the volume within defined period
	FR_LOCKED,				//!< (16) The operation is rejected according to the file sharing policy
	FR_NOT_ENOUGH_CORE,		//!< (17) LFN working buffer could not be allocated
	FR_TOO_MANY_OPEN_FILES,	//!< (18) Number of open files > _FS_SHARE
	FR_INVALID_PARAMETER	//!< (19) Given parameter is invalid
} FRESULT;

/***************************************************************************//**
 *  \name FatFs module application interface
 *  \{
*******************************************************************************/
//! \fn FRESULT f_open (FIL* fp, const TCHAR* path, UINT8 mode)
//! \brief Open or create a file
//! \param fp - Pointer to the blank file object
//! \param path - Pointer to the file name
//! \param mode - Access mode and file open mode flags
FRESULT f_open (FIL* fp, const TCHAR* path, UINT8 mode);

//! \fn FRESULT f_close (FIL* fp)
//! \brief Close an open file object 
//! \param fp - Pointer to the file object to be closed
FRESULT f_close (FIL* fp);

//! \fn FRESULT f_read (FIL* fp, void* buff, UINT16 btr, UINT16* br)
//! \brief Read data from a file
//! \param fp - Pointer to the file object
//! \param buff - Pointer to data buffer
//! \param btr - Number of bytes to read
//! \param br - Pointer to number of bytes read
FRESULT f_read (FIL* fp, void* buff, UINT16 btr, UINT16* br);

//! \fn FRESULT f_write (FIL* fp, const void* buff, UINT16 btw, UINT16* bw)
//! \brief Write data to a file
//! \param fp - Pointer to the file object
//! \param buff - Pointer to the data to be written
//! \param btw - Number of bytes to write
//! \param bw - Pointer to number of bytes written
FRESULT f_write (FIL* fp, const void* buff, UINT16 btw, UINT16* bw);

//! \fn FRESULT f_forward (FIL* fp, UINT16(*func)(const UINT8*,UINT16), UINT16 btf, UINT16* bf)
//! \brief Forward data to the stream 
//! \param fp - Pointer to the file object
//! \param func - Pointer to the streaming function
//! \param btf - Number of bytes to forward
//! \param bf - Pointer to number of bytes forwarded
FRESULT f_forward (FIL* fp, UINT16(*func)(const UINT8*,UINT16), UINT16 btf, UINT16* bf);

//! \fn FRESULT f_lseek (FIL* fp, UINT32 ofs)
//! \brief Move file pointer of a file object
//! \param fp - Pointer to the file object
//! \param ofs - File pointer from top of file
FRESULT f_lseek (FIL* fp, UINT32 ofs);

//! \fn FRESULT f_truncate (FIL* fp)
//! \brief Truncate file
//! \param fp - Pointer to the file object
FRESULT f_truncate (FIL* fp);

//! \fn FRESULT f_sync (FIL* fp)
//! \brief Flush cached data of a writing file
//! \param fp - Pointer to the file object
FRESULT f_sync (FIL* fp);

//! \fn FRESULT f_opendir (DIR* dp, const TCHAR* path)
//! \brief Open a directory
//! \param dp - Pointer to directory object to create
//! \param path - Pointer to the directory path
FRESULT f_opendir (DIR* dp, const TCHAR* path);

//! \fn FRESULT f_closedir (DIR* dp)
//! \brief Close an open directory
//! \param dp - Pointer to the directory object to be closed
FRESULT f_closedir (DIR* dp);

//! \fn FRESULT f_readdir (DIR* dp, FILINFO* fno)
//! \brief Read a directory item
//! \param dp - Pointer to the open directory object
//! \param fno - Pointer to the file information to return
FRESULT f_readdir (DIR* dp, FILINFO* fno);

//! \fn FRESULT f_findfirst (DIR* dp, FILINFO* fno, const TCHAR* path, const TCHAR* pattern)
//! \brief Find first file
//! \param dp - Pointer to the blank directory object
//! \param fno - Pointer to the file information structure
//! \param path - Pointer to the directory to open
//! \param pattern - Pointer to the matching pattern
FRESULT f_findfirst (DIR* dp, FILINFO* fno, const TCHAR* path, const TCHAR* pattern);

//! \fn FRESULT f_findnext (DIR* dp, FILINFO* fno)
//! \brief Find next file
//! \param dp - Pointer to the open directory object
//! \param fno - Pointer to the file information structure
FRESULT f_findnext (DIR* dp, FILINFO* fno);	

//! \fn FRESULT f_mkdir (const TCHAR* path)
//! \brief Create a sub directory
//! \param path - Pointer to the directory path
FRESULT f_mkdir (const TCHAR* path);

//! \fn FRESULT f_unlink (const TCHAR* path)
//! \brief Delete an existing file or directory
//! \param path - Pointer to the file or directory path
FRESULT f_unlink (const TCHAR* path);

//! \fn FRESULT f_rename (const TCHAR* path_old, const TCHAR* path_new)
//! \brief Rename/Move a file or directory 
//! \param path_old - Pointer to the object to be renamed
//! \param path_new - Pointer to the new name
FRESULT f_rename (const TCHAR* path_old, const TCHAR* path_new);

//! \fn FRESULT f_stat (const TCHAR* path, FILINFO* fno)
//! \brief Get file status
//! \param path - Pointer to the file path
//! \param fno - Pointer to file information to return
FRESULT f_stat (const TCHAR* path, FILINFO* fno);

//! \fn FRESULT f_chmod (const TCHAR* path, UINT8 attr, UINT8 mask)
//! \brief Change attribute of the file/dir
//! \param path - Pointer to the file path
//! \param attr - Attribute bits
//! \param mask - Attribute mask to change
FRESULT f_chmod (const TCHAR* path, UINT8 attr, UINT8 mask);

//! \fn FRESULT f_utime (const TCHAR* path, const FILINFO* fno)
//! \brief Change times-tamp of the file/dir
//! \param path - Pointer to the file/directory name
//! \param fno - Pointer to the time stamp to be set
FRESULT f_utime (const TCHAR* path, const FILINFO* fno);

//! \fn FRESULT f_chdir (const TCHAR* path)
//! \brief Change current directory
//! \param path - Pointer to the directory path
FRESULT f_chdir (const TCHAR* path);

//! \fn FRESULT f_chdrive (const TCHAR* path)
//! \brief Change current drive 
//! \param path - Drive nubmer
FRESULT f_chdrive (const TCHAR* path);

//! \fn FRESULT f_getcwd (TCHAR* buff, UINT16 len)
//! \brief Get current directory 
//! \param buff - Pointer to the directory path
//! \param len - Size of path
FRESULT f_getcwd (TCHAR* buff, UINT16 len);

//! \fn FRESULT f_getfree (const TCHAR* path, UINT32* nclst, FATFS** fatfs)
//! \brief Get number of free clusters on the drive
//! \param path - Path name of the logical drive number
//! \param nclst - Pointer to a variable to return number of free clusters
//! \param fatfs - Pointer to return pointer to corresponding file system object
FRESULT f_getfree (const TCHAR* path, UINT32* nclst, FATFS** fatfs);

//! \fn FRESULT f_getlabel (const TCHAR* path, TCHAR* label, UINT32* vsn)
//! \brief Get volume label
//! \param path - Path name of the logical drive number
//! \param label - Pointer to a buffer to return the volume label
//! \param vsn - Pointer to a variable to return the volume serial number
FRESULT f_getlabel (const TCHAR* path, TCHAR* label, UINT32* vsn);

//! \fn FRESULT f_setlabel (const TCHAR* label)
//! \brief Set volume label 
//! \param label - Pointer to the volume label to set
FRESULT f_setlabel (const TCHAR* label);

//! \fn FRESULT f_mount (FATFS* fs, const TCHAR* path, UINT8 opt)
//! \brief Mount/Unmount a logical drive
//! \param fs - Pointer to the file system object (NULL:unmount)
//! \param path - Logical drive number to be mounted/unmounted
//! \param opt - 0:Do not mount (delayed mount), 1:Mount immediately
FRESULT f_mount (FATFS* fs, const TCHAR* path, UINT8 opt);

//! \fn FRESULT f_mkfs (const TCHAR* path, UINT8 sfd, UINT16 au)
//! \brief Create a file system on the volume
//! \param path - Logical drive nubmer
//! \param sfd - Partitioning rule 0:FDISK 1:SFD 
//! \param au - Size of allocation unit in unit of byte or sector
FRESULT f_mkfs (const TCHAR* path, UINT8 sfd, UINT16 au);

//! \fn FRESULT f_fdisk (UINT8 pdrv, const UINT32 szt[], void* work)
//! \brief Divide a physical drive into some partitions
//! \param pdrv - Physical drive number
//! \param szt - Pointer to the size table for each partitions
//! \param work - Pointer to the working buffer
FRESULT f_fdisk (UINT8 pdrv, const UINT32 szt[], void* work);

//! \fn int f_putc (TCHAR c, FIL* fp)
//! \brief Put a character to the file
//! \param c - A character to be output
//! \param fp - Pointer to the file object
int f_putc (TCHAR c, FIL* fp);

//! \fn int fs_puts (const TCHAR* str, FIL* cp)
//! \brief Put a string to the file 
//! \param str - Pointer to the string to be output
//! \param cp - Pointer to the file object
int fs_puts (const TCHAR* str, FIL* cp);

//! \fn int fs_printf (FIL* fp, const TCHAR* str, ...)
//! \brief Put a formatted string to the file
//! \param fp - Pointer to the file object
//! \param str - Pointer to the format string
//! \param ... - Optional arguments
int fs_printf (FIL* fp, const TCHAR* str, ...);

//! \fn TCHAR* fs_gets (TCHAR* buff, int len, FIL* fp)
//! \brief Get a string from the file 
//! \param buff - Pointer to the string buffer to read
//! \param len - Size of string buffer (number of characters)
//! \param fp - Pointer to the file object
TCHAR* fs_gets (TCHAR* buff, int len, FIL* fp);

#define f_eof(fp) ((int)((fp)->fptr == (fp)->fsize))
#define f_error(fp) ((fp)->err)
#define f_tell(fp) ((fp)->fptr)
#define f_size(fp) ((fp)->fsize)
#define f_rewind(fp) f_lseek((fp), 0)
#define f_rewinddir(dp) f_readdir((dp), 0)

#ifndef EOF
#define EOF (-1)
#endif
 //! \}

/***************************************************************************//**
 *  \name Additional user defined functions  
 *  \{
*******************************************************************************/

//! \name RTC function
//! \{
#if !_FS_READONLY && !_FS_NORTC
UINT32 get_fattime (void);
#endif
//! \}

//! \name Unicode support functions
//! \{
#if _USE_LFN							/* Unicode - OEM code conversion */
WCHAR ff_convert (WCHAR chr, UINT16 dir);	/* OEM-Unicode bidirectional conversion */
WCHAR ff_wtoupper (WCHAR chr);			/* Unicode upper-case conversion */
#if _USE_LFN == 3						/* Memory functions */
void* ff_memalloc (UINT16 msize);			/* Allocate memory block */
void ff_memfree (void* mblock);			/* Free memory block */
#endif
#endif
//! \}

//! \name Sync functions
//! \{
#if _FS_REENTRANT
int ff_cre_syncobj (UINT8 vol, _SYNC_t* sobj);	/* Create a sync object */
int ff_req_grant (_SYNC_t sobj);				/* Lock sync object */
void ff_rel_grant (_SYNC_t sobj);				/* Unlock sync object */
int ff_del_syncobj (_SYNC_t sobj);				/* Delete a sync object */
#endif
//! \}
//! \}

/***************************************************************************//**
 *  \name Flags and offset address
 *  \{
*******************************************************************************/
//! \name File access control and file status flags (FIL.flag)
//! \{
#define	FA_READ				0x01
#define	FA_OPEN_EXISTING	0x00

#if !_FS_READONLY
#define	FA_WRITE			0x02
#define	FA_CREATE_NEW		0x04
#define	FA_CREATE_ALWAYS	0x08
#define	FA_OPEN_ALWAYS		0x10
#define FA__WRITTEN			0x20
#define FA__DIRTY			0x40
#endif
//! \}

//! \name FAT sub type (FATFS.fs_type)
//! \{
#define FS_FAT12	1
#define FS_FAT16	2
#define FS_FAT32	3
//! \}

//! \name File attribute bits for directory entry
//! \{

//! \def AM_RDO
//! \brief Read only
#define	AM_RDO	0x01

//! \def AM_HID
//! \brief Hidden
#define	AM_HID	0x02

//! \def AM_SYS
//! \brief System
#define	AM_SYS	0x04

//! \def AM_VOL
//! \brief Volume label
#define	AM_VOL	0x08

//! \def AM_LFN
//! \brief LFN entry
#define AM_LFN	0x0F

//! \def AM_DIR
//! \brief Directory
#define AM_DIR	0x10

//! \def AM_ARC
//! \brief Archive
#define AM_ARC	0x20

//! \def AM_MASK
//! \brief Mask of defined bits
#define AM_MASK	0x3F
//! \}

//! \def CREATE_LINKMAP
//! \brief Fast seek feature
#define CREATE_LINKMAP	0xFFFFFFFF

/***************************************************************************//**
 *  \name Multi-UINT8 word access macros
 *  \{
*******************************************************************************/
#if _WORD_ACCESS == 1	/* Enable word access to the FAT structure */
#define	LD_WORD(ptr)		(UINT16)(*(UINT16*)(UINT8*)(ptr))
#define	LD_DWORD(ptr)		(UINT32)(*(UINT32*)(UINT8*)(ptr))
#define	ST_WORD(ptr,val)	*(UINT16*)(UINT8*)(ptr)=(UINT16)(val)
#define	ST_DWORD(ptr,val)	*(UINT32*)(UINT8*)(ptr)=(UINT32)(val)
#else					/* Use UINT8-by-UINT8 access to the FAT structure */
#define	LD_WORD(ptr)		(UINT16)(((UINT16)*((UINT8*)(ptr)+1)<<8)|(UINT16)*(UINT8*)(ptr))
#define	LD_DWORD(ptr)		(UINT32)(((UINT32)*((UINT8*)(ptr)+3)<<24)|((UINT32)*((UINT8*)(ptr)+2)<<16)|((UINT16)*((UINT8*)(ptr)+1)<<8)|*(UINT8*)(ptr))
#define	ST_WORD(ptr,val)	*(UINT8*)(ptr)=(UINT8)(val); *((UINT8*)(ptr)+1)=(UINT8)((UINT16)(val)>>8)
#define	ST_DWORD(ptr,val)	*(UINT8*)(ptr)=(UINT8)(val); *((UINT8*)(ptr)+1)=(UINT8)((UINT16)(val)>>8); *((UINT8*)(ptr)+2)=(UINT8)((UINT32)(val)>>16); *((UINT8*)(ptr)+3)=(UINT8)((UINT32)(val)>>24)
#endif
 //! \}
#ifdef __cplusplus
}
#endif
//! \}
//! \}
#endif
// End of file
