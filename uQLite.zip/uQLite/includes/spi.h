/*******************************************************************************
** File:        spi.h
** Description:	Contains the routines and definitions for spi.c
**              
** Copyright 2015 Embedded Lab Design - ALL RIGHTS RESERVED.
**
*******************************************************************************/
#ifndef __SPI_H__
#define __SPI_H__

/*******************************************************************************
**																			  **
**  							    DEFINITIONS								  **	
**																			  **
*******************************************************************************/

/*******************************************************************************
***************** ESPI Transmit Data Command Register (ESPIxTDCR) **************
*******************************************************************************/
#define TEOF	(1<<1) // This Bit is used in Master Mode to indicate that the 
                       // data in the transmit data register is the last byte of
					   // the transfer or frame. When the last byte has been
					   // sent SS (and SSV) will change state, and TEOF will
					   // automatically clear
					   // Flag if the data is the last character in the message.
#define SSV		(1<<0) // When SSIO=1, writes to this register will control the 
                       // value output on the SS pin.

/*******************************************************************************
************************ ESPI Control Register (ESPIxCTL) **********************
*******************************************************************************/
#define DIRQS	(1<<7) // This bit is used to disable or enable data (TDRE and 
                       // RDRNE) interrupts. 
					   // TDRE and RDRNE assertions will cause an interrupt.
					   // TUND, COL, ABT and ROVR will also cause interrupts.
#define ESPIEN1	(1<<6) // ESPI Enable and Direction Control
#define ESPIEN0 (1<<0) // 00 - The ESPI block is disabled
                       // 01 - Receive only mode.
					   // 10 - Transmit Only Mode
					   // 11 - Transmit / Receive Mode
#define BRGCTL	(1<<5) // The function of this bit depends upon ESPIEN 1,0.
                       // If ESPI is disabled
					   // 0 - The BRG timer function is disabled
					   // 1 - The BRG timer is enabled.
					   // If ESPI is enabled
					   // 0 - Reading the Baud Rate High and Low Registers
					   // returns the BRG reload value. if MMEN =1, the BRG is
					   // enabled to generate SCK. If MMEN = 0, the BRG is
					   // enabled to provide a Slave SCK time-out.
#define PHASE	(1<<4) // Sets the phase relationship of the data to the clock.
#define CLKPOL	(1<<3) // 0 - SCK idles LOW
                       // 1 - SCK idles HIGH
#define WOR		(1<<2) // 0 - ESPI signal pins not configured for open drain.					   
					   // 1 - All four ESPI signal pins (SCK, SS, MISO and MOSI)
					   //     configured for open-drain functions.
#define MMEN	(1<<1) // 0 - Data out on MISO, data in on MOSI,SCK is an input
					   //     Slave mode.
					   // 1 - Data out on MOSI, data in on MISO,SCK is an output
					   //     Master mode.

/*******************************************************************************
********************** ESPI Mode Register (ESPIxMODE) **************************
*******************************************************************************/
#define SSMD7	(1<<7) // Slave Select Mode
#define SSMD6	(1<<6) // This field selects the behavior of the SS.
#define SSMD5	(1<<5) // 000- SPI mode, the SS pin is driven directly from the
                       //      SSV bit in the transmit data command register.
					   //      The master software should set SSV (or a GPIO)
					   //      to the asserted state. After the last RDRNE event
					   //      SSV will be automatically deasserted by hardware.
					   // 001- Loop back mode
					   // 010- I2S mode.
#define NUMBITS2 (1<<4)// Number of Bits Per Character to transfer
#define NUMBITS1 (1<<3)// 000- 8 bits
#define NUMBITS0 (1<<2)// 001- 1 bit
					   // 010- 2 bits
                       // 011- 3 bits
                       // 100- 4 bits
                       // 101- 5 bits
                       // 110- 6 bits
                       // 111- 7 bits
#define SSIO	(1<<1) // Slave Select I/O 
                       // 0- SS pin configured as an input (slave mode )
					   // 1- SS pin configured as output   (master mode)
#define SSPO	(1<<0) // Slave Select Polarity
                       // 0- SS is active Low (SSV = 1 corresponds to SS = 0)
					   // 1- SS is active High(SSV = 1 corresponds to SS = 1)
					   
/*******************************************************************************
********************** ESPI Status Register (ESPIxSTAT) ************************
*******************************************************************************/
#define TDRE	(1<<7) // Transmit Data Register Empty
                       // 0- Transmit Data Register is full or ESPI is disabled
					   // 1- Transmit Data Register is empty. A write to the
					   //    Data Register clears this bit
#define TUND	(1<<6) // Transmit Underrun
                       // 0- A Transmit Underrun error has not occured.
					   // 1- A Transmit Underrun error has occured.
#define COL		(1<<5) // Collision
					   // 0- A multimaster collision has not occured.
					   // 1- A multimaster collision has occured.
#define ABT		(1<<4) // Slave mode transaction abort
                       // 0- No abortion
					   // 1- Abortion has occured
#define ROVR	(1<<3) // Receive Overrun
                       // 0- Overrun has not occured
					   // 1- Overrun has occured.
#define RDRNE	(1<<2) // Receive Data Register Not Empty
                       // 0- Receive Data Register is empty.
					   // 1- Receive Data Register is not empty.
#define TFST	(1<<1) // Transfer Status
                       // 0- No data transfer is in progress
					   // 1- Data transfer is currently in progress
#define SLAS	(1<<0) // Slave Select - Reading this returns the current value 
                       //                of the SS pin.
					   // 0- SS pin input is LOW
					   // 1- SS pin input is HIGH				   
					   
/*******************************************************************************
**																			  **
**  					      FUNCTION PROTOTYPES							  **	
**																			  **
*******************************************************************************/
VOID SpiInit       (VOID);
VOID SpiSendByte   (INT8 cData);
VOID SpiSendString (INT8 *acStr, INT8 cLen);
					   
#endif
/*************************************************************** End of File **/