#ifndef __APPVARS_H__
#define __APPVARS_H__


#define PROJECT_NAME        "GEN"       // Genesis
#define FIRMWARE_VERSION    "0002"      // v00.02

#define KIOSK_DVC_CODE      'K'
#define DISPLAY_DVC_CODE    'D'
#define CALLER_DVC_CODE     'C'

#define KIOSK_DVCID_MIN     (0)
#define KIOSK_DVCID_MAX     (999)

#define DISPLAY_DVCID_MIN   (1000)
#define DISPLAY_DVCID_MAX   (1999)

#define CALLER_DVCID_MIN    (2000)
#define CALLER_DVCID_MAX    (9999)

#ifdef _CALLER_DVC
#define SVCLIST_MAXNUM      (12)                    // max services the whole system can offer
#define RMKSLIST_MAXNUM     (10)                    // max remarks on DONE
#else
#define SVCLIST_MAXNUM      (10)                    // max services the whole system can offer
#define RMKSLIST_MAXNUM     (5)                    // max remarks on DONE
#endif
#define STRLEN_MAX          (16)                    // 16 chars max length for strings equiv to 16 chars per line of LCD
#define DVCID_LEN           (5)
#define ROUTER_LEN          (16)
#define FN_LEN              (32)
#define COMPANY_FN_LEN      (48)

#define APPVARS_STA_ADDR        (0xFE00)        // start address of app variables in flash
#define APPVARS_STA_ADDR_BAN    (0xFFF0)        // start address of app variables not allowed for writing
#define APPVARS_END_ADDR        (0xFFFF)        // end address of app vars in flash


#define VARTYPE_STRING          (0)
#define VARTYPE_BYTE            (1)
#define VARTYPE_SHORT           (2)

typedef struct
{
	CHAR *acVarName;
	UINT16 uiOffset;
    UINT8 ucVarType;
    UINT16 uiVarLen;
}tAPPVARS_Map;
extern tAPPVARS_Map APPVARS_Map[];

BOOL APPVARS_Init(VOID);
VOID APPVARS_Read(UINT16 uiOffset, UINT8 *aucData, UINT16 uiLen);
VOID APPVARS_Write(UINT16 uiOffset, UINT8 *aucData, UINT16 uiLen);
VOID APPVARS_FinalizeWrite(VOID);
CHAR *APPVARS_GetSerialNumber(CHAR *cSerial);



#endif // __APPVARS_H__
// End of file