/***************************************************************************//**
 *  \addtogroup BSP_Z8F6482
 *  \{
 *  \file z8sysclk.h
 *  \brief Clock System Routines 
 *
 *   There are several clock sources to choose from: \n
 *   1. Internal Watchdog Timer Oscillator (WT)\n
 *   2. High Frequency Crystal Oscillator (HFXO)\n
 *   3. External Clock   (CLKIN)\n
 *   4. External Clock 2 (CLK2IN)\n
 *   5. Low Frequency Crystal Oscillator (LFXO)\n
 *   6. Internal Precision Oscillator (IPO)\n\n
 *   
 *   Three Major Clock Systems\n
 *   1. System Clock\n
 *   2. Peripheral Clock\n   
 *   3. Phase-Locked Loop Clock  (48 MHz)\n
 *
 *  \version 1.0.0
 *  \date 01 July 2015
 *  \author MBordador
 *  
 *  Copyright (C) 2015 Embedded Lab Design\n
 *  All Rights Reserved
*******************************************************************************/
#ifndef __SYSCLOCK_H__
#define __SYSCLOCK_H__

#include <defines.h>

/***************************************************************************//**
 *  \name Peripheral Clock Sources
 *  \{
*******************************************************************************/
#define IPO             (0)
#define LFXO            (1<<3)
#define CLK2IN          (1<<4)
//! \}

/***************************************************************************//**
 *  \name PLL Clock Sources
 *  \{
*******************************************************************************/
#define PLL             (1)
#define HFXO            (0)
#define CLKIN           (2)
//! \}

/***************************************************************************//**
 *  \name System Clock 
 *  \{
*******************************************************************************/
#define PCLK            (0)
#define DCOFLL          (1)
#define PLLSEL          (2)
#define PLLBLK          (3)
#define WTO             (4)
//! \}

/***************************************************************************//**
 *  \fn  VOID SetPClkSelect(UINT8 ucSource, UINT8 bStopModeOp)
 *  \brief Sets the peripheral clock
 *  \param ucSource - peripheral clock source
 *  \param bStopModeOp - TRUE: if using stop mode\n FALSE: if not using stop mode
*******************************************************************************/
VOID SetPClkSelect(UINT8 ucSource, UINT8 bStopModeOp);

VOID SetPLLSelect      (UINT8 ucSource,
                        UINT32 ulSpeed);   

VOID SetPLL            (UINT8 bPLLBlockEnable,
                        UINT8 ucSource,
                        UINT32 ulSpeed);
                        
VOID SetDCO            (UINT8 bDCOEn,
                        UINT8 bFLLLock,
                        UINT32 ulSpeed);    
                        
VOID SetSysClkPLLBlock (UINT8 ucSource, 
                        UINT32 ulSpeed);
                        
VOID SetSysClkPCLK     (UINT8 ucSource, 
                        UINT8 bStopModeOp);
                        
VOID SetSysClkDCO      (UINT8 ucSource,
                        UINT32 ulSpeed);
                        
VOID SetSysClkPLLClkIn (UINT8 ucSource,
                        UINT32 ulSpeed);
                        
VOID SetClock          (UINT8 ucClockBlock,
                        UINT8 ucSource, 
                        UINT32 ulSpeed);
                        
VOID SetSysClkWTO      (VOID); 

//! \}
#endif
// End of file

