#ifndef __KVARS_H__
#define __KVARS_H__

#include "appvars.h"

#define MY_DVC_CODE         KIOSK_DVC_CODE

#define NUM_SERVICES        (3)         // Number of services the system offers
#define NUM_CALLERS         (5)         // Number of callers available
#define NUM_EMPTYROMSPACE   (113)

extern rom CHAR cRouterName[ROUTER_LEN];
extern rom CHAR cRouterPwd[ROUTER_LEN];
extern rom CHAR cLogoPath[FN_LEN];
extern rom CHAR cCompanyName[COMPANY_FN_LEN];
extern rom CHAR cServerIp[STRLEN_MAX];
extern rom CHAR cSvcList[SVCLIST_MAXNUM][STRLEN_MAX];
extern rom CHAR cRmksList[RMKSLIST_MAXNUM][STRLEN_MAX];
extern rom UINT8 ucSysRmksMax;
extern rom UINT16 uiServerPort;
extern rom UINT8 ucCallerDb[SVCLIST_MAXNUM * 2];
extern rom UINT8 ucReserved3[NUM_EMPTYROMSPACE];
extern rom UINT8 ucMyIdRsv[5];
extern rom CHAR cMyDvcHdr;
extern rom UINT16 uiMyDvcId;


#endif // __KVARS_H__