/***************************************************************************//**
 *  \addtogroup BSP_Z8F6482
 *  \{
 *  \file z8reset.h
 *  \brief Reset, SMR, LVD, Low Power Mode, & WDT Peripherals Routines
 *  \version 1.0.0
 *  \date 01 July 2015
 *  \author MBordador
 *  
 *  Copyright (C) 2015 Embedded Lab Design\n
 *  All Rights Reserved
*******************************************************************************/
#ifndef __Z8RESET_H__
#define __Z8RESET_H__

#include <ez8.h>
#include "mcu_conf.h"


#if (_Z8WDT_INUSE == 1)
//! \def WDT_KICK()
//! \brief Refresh watchdog timer
#define WDT_KICK()          asm("WDT")

//! \fn VOID WDT_Init(VOID)
//! \brief Initializes the watchdog timer
//! \todo Add parameter to customize watchdog time
VOID WDT_Init(VOID);
#endif

#if (_Z8LPM_INUSE == 1)
//! \def MCU_STOP()
//! \brief If _Z8LPM_INUSE == 1, stops the MCU program counter using HALT mode \n
//!  If _Z8LPM_INUSE == 2, stops the MCU program counter using STOP mode
#define MCU_STOP()          asm("HALT")
#elif (_Z8LPM_INUSE == 2)
#define MCU_STOP()          asm("STOP")
#endif
//! \}
#endif // __Z8RESET_H__