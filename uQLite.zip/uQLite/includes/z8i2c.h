#ifndef _I2C_H_
#define _I2C_H_


void I2C_Init(VOID);
int I2C_WriteToSlave(unsigned char addr, unsigned char *data, unsigned char len);
int I2C_ReadFromSlave(unsigned char addr, unsigned char *data, unsigned char len);
int WriteRead(unsigned char addr, unsigned char *wrData, 
    unsigned char wrLen, unsigned char *rdData, unsigned char rdLen);
#endif	// _I2C_H_

// End of file