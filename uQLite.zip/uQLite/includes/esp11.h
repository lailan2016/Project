#ifndef __ESP11_H__
#define __ESP11_H__

#include "main.h"   // tSYSERR
#include "appvars.h"    // DVCID_LEN
#include "tcp.h"

////////////////////////////////////////////////////////////////////////////////
// ESP8266
////////////////////////////////////////////////////////////////////////////////
typedef enum
{
    WIFISTAT_INIT = 0,      // initializing module
    WIFISTAT_CONNECTED,     // module connected to network
    WIFISTAT_COMMREADY,     // waiting for '+' in [+IPD:<id>,<len>:<data ending in '\n'>]
    WIFISTAT_RXING,         // receiving succeeding data in [+IPD:<id>,<len>:<data ending in '\n'>]
    WIFISTAT_RXCOMPLETE     // received '\n' in [+IPD:<id>,<len>:<data ending in '\n'>]
}tESP11_STATE;
#define WIFISTAT_SENDING        (0x80)

#define WIFI_CONNECT_RETRIES    (3)     // Number of times to retry connecting to network, if CWJAP fails

#define WIFIRXERR_NORX          (-1)
#define WIFIRXERR_INCOMPLETE    (-2)

////////////////////////////////////////////////////////////////////////////////
// TCP Communications 
////////////////////////////////////////////////////////////////////////////////
/*#define TCP_TKTNUM_LEN          (4)
#define TCP_DVCID_LEN           (DVCID_LEN)
#define TCP_DATE_LEN            (10)
#define TCP_TIME_LEN            (8)
#define TCP_RMKS_LEN            (2)
#define TCP_SVCIDX_LEN          (2)

#define TCP_SEND_RETRIES        (3)

#define TCP_PROT_SEPARATOR       ','
#define TCP_PROT_EOF             '\n'
#define TCP_PROT_SOF             '!'

// Request IDs
#define TCP_RQSTID_CALL         ('1')
#define TCP_RQSTID_SKIP         ('2')
#define TCP_RQSTID_DONE         ('3')
#define TCP_RQSTID_DISPLAY      ('4')
#define TCP_RQSTID_MINVAL       (TCP_RQSTID_CALL)
#define TCP_RQSTID_MAXVAL       (TCP_RQSTID_DISPLAY)
*/

#define TIMEOUT_MAIN        (200)       // (200 * BSP_MCT_INTERVAL) = 1 sec
#define TIMEOUT_LCD         (1)         // (1 * BSP_MCT_INTERVAL) = 5 msec
#define TIMEOUT_WIFI        (100)		// (100 * BSP_MCT_INTERVAL) = 500 msec
#define TIMEOUT_USB         (6000)      // (6000 * BSP_MCT_INTERVAL) = 30 sec

// Timers Using MCT thru Callback Function
#define LEDBLINK_STARTUP    (100)       // (100 * BSP_MCT_INTERVAL) = 500 msec  
#define LEDBLINK_SYSERR     (20)        // (20 * BSP_MCT_INTERVAL) = 100 msec

// TODO:: Is it possible to lower down these delay times????
// If minimum delay times is achieved, change each timeout, with their own timers from mct
#define TCP_COMMS_TMO       (20)        // (20 * TIMEOUT_WIFI) = 10 sec
#define WIFI_NETWORK_TMO    (20)        // (20 * TIMEOUT_WIFI) = 10 sec
#define ATCMD_TIMEOUT		(10)		// (10 * TIMEOUT_WIFI) = 5 sec
#define ESP_RESET_TMO       (30)        // (30 * TIMEOUT_WIFI) = 15 sec
#define ESP_AVOID_RESET     (2)         // (2 * TIMEOUT_WIFI) = 1 sec


typedef struct
{
    CHAR cSOF;
    CHAR acFromDvcId[TCP_DVCID_LEN];
    CHAR cSeparator1;
    CHAR acToDvcId[TCP_DVCID_LEN];
    CHAR cSeparator2;
    CHAR cRqstId;
    CHAR cSeparator3;
    CHAR acTicketNum[TCP_TKTNUM_LEN];
    CHAR cSeparator4;
    CHAR acRemarks[TCP_RMKS_LEN];
    CHAR cEOF;
    CHAR cNullTermination;
}tTCP_Request;

typedef struct
{
    CHAR cSOF;
    CHAR acFromDvcId[TCP_DVCID_LEN];
    CHAR cSeparator1;
    CHAR acToDvcId[TCP_DVCID_LEN];
    CHAR cSeparator2;
    CHAR acSvcIdx[TCP_SVCIDX_LEN];
    CHAR cSeparator3;
    CHAR acTicketNum[TCP_TKTNUM_LEN];
    //CHAR cSeparator4;
    //CHAR acDate[TCP_DATE_LEN];
    //CHAR cSeparator5;
    //CHAR acTime[TCP_TIME_LEN];
    CHAR cEOF;
    CHAR cNullTermination;
}tTCP_Response;

// SERVER: IPD,x,xx:<tTCP_Request>
// CLIENT: IPD,xx:<tTCP_Response>
typedef struct
{
    CHAR acHdr[3];
    CHAR cSeparator1;
    
    #ifndef _CALLER_DVC
    CHAR cLinkId;
    CHAR cSeparator2;
    #endif
    
    CHAR acLen[2];
    CHAR cSeparator3;
    
    #ifndef _CALLER_DVC
    tTCP_Request tRequest;
    #else
    tTCP_Response tResponse;
    #endif
}tTCP_RxData;

#define IPADDR_LEN      (16)
typedef struct
{
    CHAR IpAddress[IPADDR_LEN];
    UINT16 Port;
}tServerInfo;

VOID WifiInit(VOID);
VOID WifiConnectToNetwork(CHAR *ssid, CHAR *ssidPwd);

#ifdef _SERVER
VOID WifiStartListen(UINT16 port);
VOID WifiSendString(CHAR *strData, UINT8 strLen, UINT8 linkId);
BOOL WifiGetString(CHAR *strData, UINT8 *linkId);
#else
VOID WifiConnectToServer(tServerInfo server);
VOID WifiDisconnectFromServer(VOID);
VOID WifiSendString(CHAR *strData, UINT8 strLen, tServerInfo server);
BOOL WifiGetString(CHAR *strData);
#endif


#endif // __ESP11_H__
// End of file