/***************************************************************************//**
 *  \addtogroup ThermalPrinter
 *  \brief Executes thermal printer commands. 
 *  \{
 *  \file thermal.h
 *  \brief Thermal Printer routines using UART.
 *  \version 1.0.0
 *  \date 01 July 2015
 *  \author MBordador
 *  
 *  Copyright (C) 2015 Embedded Lab Design\n
 *  All Rights Reserved
*******************************************************************************/
#ifndef __PRNTR_H__
#define __PRNTR_H__

#include <defines.h>

/*
#define PRNTR_UARTCH      (UART0)
#define PRNTR_BAUDRATE    (BAUD_19200)
#define PRNTR_PARITY      (NOPARITY)
#define PRNTR_STOPBITS    (STOP_1)
#define PRNTR_PRIORITY    (INTPRIORITY_NOMINAL)
*/

//! \name Line Spacing Constants
//! \{
#define PRNTR_LINESPACE_DEFAULT       (30)
#define PRNTR_ALIGNMENT_LEFT          (0)
#define PRNTR_ALIGNMENT_CENTER        (1)
#define PRNTR_ALIGNMENT_RIGHT         (2)
//! \}

//! \name Character Setting Constants
//! \{
#define PRNTR_PRINTMODE_DELETELINE        (BIT6) // no significant changes
#define PRNTR_PRINTMODE_DBLWIDTH          (BIT5)
#define PRNTR_PRINTMODE_DBLHEIGHT         (BIT4)
#define PRNTR_PRINTMODE_EMPHASIZED        (BIT3)
#define PRNTR_PRINTMODE_UPSIDEDOWN        (BIT2) // no significant changes
#define PRNTR_PRINTMODE_BLACKBACKGROUND   (BIT1) // no significant changes
#define PRNTR_PRINTMODE_CHARFONT_9x17     (BIT0)
//! \}

//! \name Bit Image Constants
//! \{
#define PRNTR_IMAGEMODE_8DOT_SINGLDENSITY         (0)
#define PRNTR_IMAGEMODE_8DOT_DOUBLEDENSITY        (1)
#define PRNTR_IMAGEMODE_24DOT_SINGLEDENSITY       (32)
#define PRNTR_IMAGEMODE_24DOT_DOUBLEDENSITY       (33)

#define PRNTR_IMAGEPRINTMODE_NORMAL               (0)
#define PRNTR_IMAGEPRINTMODE_DOUBLEWIDTH          (1)
#define PRNTR_IMAGEPRINTMODE_DOUBLEHEIGHT         (2)
#define PRNTR_IMAGEPRINTMODE_QUADRUPLE            (3)
//! \}

//! \name Bar Code Constants
//! \{
#define PRNTR_BARCODEHRI_NONE             (0)
#define PRNTR_BARCODEHRI_ABOVE            (1)
#define PRNTR_BARCODEHRI_BELOW            (2)
#define PRNTR_BARCODEHRI_BOTH             (3)

#define PRNTR_BARCODE_HEIGHT_DEFAULT      (50)

#define PRNTR_BARCODEWIDTH_MIN            (2)
#define PRNTR_BARCODEWIDTH_DEFAULT        (3)
#define PRNTR_BARCODEWIDTH_MAX            (6)

#define PRNTR_BARCODETYPE_UPCA            (0)
#define PRNTR_BARCODETYPE_UPCE            (1)
#define PRNTR_BARCODETYPE_EAN13           (2)
#define PRNTR_BARCODETYPE_EAN8            (3)
#define PRNTR_BARCODETYPE_CODE39          (4)
#define PRNTR_BARCODETYPE_ITF             (5)
#define PRNTR_BARCODETYPE_CODABAR         (6)
//! \}

//! \name Miscellaneous Function Constants
//! \{
#define PRNTR_PARAM_DOTS_DEFAULT          (7)
#define PRNTR_PARAM_HEATTIME_DEFAULT      (80)
#define PRNTR_PARAM_HEATINTERVAL_DEFAULT  (2)

#define PRNTR_BREAKTIME_250USEC           (1 << 5)
#define PRNTR_BREAKTIME_500USEC           (2 << 5)
#define PRNTR_BREAKTIME_750USEC           (3 << 5)
#define PRNTR_BREAKTIME_1000USEC          (4 << 5)
#define PRNTR_BREAKTIME_1250USEC          (5 << 5)
#define PRNTR_BREAKTIME_1500USEC          (6 << 5)
#define PRNTR_BREAKTIME_1750USEC          (7 << 5)

#define PRNTR_DENSITY_50PERCENT           (0)
#define PRNTR_DENSITY_55PERCENT           (1)
#define PRNTR_DENSITY_60PERCENT           (2)
#define PRNTR_DENSITY_65PERCENT           (3)
#define PRNTR_DENSITY_70PERCENT           (4)
#define PRNTR_DENSITY_75PERCENT           (5)
#define PRNTR_DENSITY_80PERCENT           (6)
#define PRNTR_DENSITY_85PERCENT           (7)
#define PRNTR_DENSITY_90PERCENT           (8)
#define PRNTR_DENSITY_95PERCENT           (9)
#define PRNTR_DENSITY_100PERCENT          (10)
//! \}

/***************************************************************************//**
 *  \name Print Commands
 *  \{
*******************************************************************************/
//! \fn VOID PRNTR_PrintLine(CHAR *acData)
//! \brief Prints an array of unsigned characters and appends a line feed at the end
//! \param acData - null-terminated array of bytes to print
VOID PRNTR_PrintLine(CHAR *strData);

//! \fn VOID PrntrPrintStr(CHAR *acData)
//! \brief Prints an array of unsigned characters
//! \param acData - null-terminated array of bytes to print
VOID PrntrPrintStr(CHAR *strData);

/***************************************************************************//**
 *  \name Line Spacing Commands
 *  \{
*******************************************************************************/
//! \fn VOID PRNTR_SetLineSpace(UINT8 n)
//! \brief Sets line spacing
//! \param n - set line space to \f$(n * 0.125mm)\f$
VOID PRNTR_SetLineSpace(UINT8 n);

//! \fn VOID PrntrSetAlignment(UINT8 ucAlignment)
//! \brief Selects justification
//! \param ucAlignment - text alignment selection
VOID PrntrSetAlignment(UINT8 ucAlignment);
//! \}

/***************************************************************************//**
 *  \name Character Setting Commands
 *  \note Unsupported commands are as follows:
 *  - ESC V n
 *  - ESC G n
 *  - ESC E n
 *  - ESC SP n
 *  - ESC SO n
 *  - ESC DC4 n
 *  - ESC - n
 *  - ESC % n
 *  - FS &
 *  - FS .
 *  - FS ! n
 *  - ESC &
 *  - ESC ? n
 *  - ESC R n
 *  - ESC t n
 *  \{
*******************************************************************************/
//! \fn VOID PrntrSetCharSize(UINT8 ucSize)
//! \brief Selects character size
//! \param ucSize - bitmapped character size [D7:D4]width [D3:D0]height
VOID PrntrSetCharSize(UINT8 ucSize);

/***************************************************************************//**
 *  \name Initialization Commands
 *  \{
*******************************************************************************/
//! \fn VOID PRNTR_Init(VOID)
//! \brief Initializes the thermal printer.
//! \todo Add parameters for customized initial settings.
VOID PRNTR_Init(VOID);

//! \fn VOID PRNTR_SetDefault(VOID)
//! \brief Initializes printer to its default value/s.
VOID PRNTR_SetDefault(VOID);
//! \}

/***************************************************************************//**
 *  \name Miscellaneous Function Commands
 *  \note Unsupported Commands are as follows:
 *  - ESC 8 n1 n2
 *  - ESC 9 n
 *  - DC2 T
 *  - FS t n
 *  - DC2 E
 *  - DC2 m d lL lH
 *  - ESC C n
 *  - GS FF
 *  - ESC i
 *  - ESC m
 *  - GS V
 *  - ESC p m
 *  - ESC c 5
 *  - GS ( F
 *  - FS C
 *  - FS S
 *  - FS s
 *  - FS d
 *  \{
*******************************************************************************/


VOID Prntr_TxIsrHdlr(VOID);
VOID Prntr_RxIsrHdlr(UINT8 ucData);
VOID PrntrFeedLines(UINT8 n);
VOID PRNTR_PartialCut(VOID);
#endif // __PRNTR_H__
// End of file