#ifndef __MAIN_H__
#define __MAIN_H__

#include "eldtypes.h"

// Timers (using MCT)
#define TIMEOUT_MAIN        (200)       // (200 * BSP_MCT_INTERVAL) = 1 sec
#define TIMEOUT_LCD         (1)         // (1 * BSP_MCT_INTERVAL) = 5 msec
#define TIMEOUT_WIFI        (100)		// (100 * BSP_MCT_INTERVAL) = 500 msec
#define TIMEOUT_USB         (6000)      // (6000 * BSP_MCT_INTERVAL) = 30 sec

// Timers Using MCT thru Callback Function
#define LEDBLINK_STARTUP    (100)       // (100 * BSP_MCT_INTERVAL) = 500 msec  
#define LEDBLINK_SYSERR     (20)        // (20 * BSP_MCT_INTERVAL) = 100 msec


#ifdef _CALLER_DVC
VOID CON_Main(VOID);
#endif

VOID WifiInitError(VOID);       // Error Code: 001
VOID NoNetworkError(VOID);      // Error Code: 002
VOID ServerModeError(VOID);     // Error Code: 003
VOID NoMemoryError(VOID);       // Error Code: 004
VOID NoSdCardError(VOID);       // Error Code: 005
VOID FileRwError(VOID);         // Error Code: 006
VOID NoServerFoundError(VOID);  // Error Code: 007
VOID WifiResetError(VOID);      // Error Code: 008
VOID NoWifiError(VOID);         // Error Code: 009

#endif // __MAIN_H__