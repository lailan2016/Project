/***************************************************************************//**
 *  \addtogroup BSP_Z8F6482
 *  \{
 *  \file z8nvds.h
 *  \brief NVDS Peripheral Routines
 *  \version 1.0.0
 *  \date 01 July 2015
 *  \author MBordador
 *  
 *  Copyright (C) 2015 Embedded Lab Design\n
 *  All Rights Reserved
*******************************************************************************/
#ifndef __Z8NVDS_H__
#define __Z8NVDS_H__

/***************************************************************************//**
 *  \fn VOID NVDS_Init(VOID)
 *  \brief Initializes the NVDS peripheral
*******************************************************************************/
VOID NVDS_Init(VOID);

/***************************************************************************//**
 *  \fn VOID NVDS_Write(UINT8 ucAddr, UINT8 *aucData, UINT16 uiLen)
 *  \brief Writes a stream of bytes into the specified NVDS address.
 *  \param ucAddr - NVDS address to start writing the specified data
 *  \param aucData - data bytes to write
 *  \param uiLen - number of bytes to write
*******************************************************************************/
VOID NVDS_Write(UINT8 ucAddr, UINT8 *aucData, UINT16 uiLen);

/***************************************************************************//**
 *  \fn VOID NVDS_Read(UINT8 ucAddr, UINT8 *aucData, UINT16 uiLen)
 *  \brief Reads a stream of bytes from the specified NVDS address.
 *  \param ucAddr - NVDS address to start reading data
 *  \param aucData - data buffer to store read data
 *  \param uiLen - number of bytes to read
*******************************************************************************/
VOID NVDS_Read(UINT8 ucAddr, UINT8 *aucData, UINT16 uiLen);

//! \}
#endif // __Z8NVDS_H__
// End of file