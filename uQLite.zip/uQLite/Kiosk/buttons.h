#ifndef __BUTTONS_H__
#define __BUTTONS_H__
   
VOID BTN_Init(VOID);	// must be called when timer is already initialized
VOID BTN_Scan(VOID);	// must be called every 5msec
UINT16 ucBTN_GetKeyEvent(VOID);
BOOL BTN_IsKeyPressed(VOID);
VOID BTN_ExecFunc(UINT16 ucKey);

#endif // __BUTTONS_H__
// End of file