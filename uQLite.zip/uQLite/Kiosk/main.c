#include <ez8.h>
#include <stdio.h>
#include <string.h>
#include "eldtypes.h"
#include "z8mct.h"
#include "main.h"
#include "esp11.h"
#include "buttons.h"

#include "ktrans.h"
#include "kvars.h"
#include "led.h"

#include "utils.h"

////////////////////////////////////////////////////////////////////////////////
// Error Handler Routines
////////////////////////////////////////////////////////////////////////////////
VOID OnSysError(UINT16 err, CHAR *acStr)
{
    LED_StartBlink(0, LEDBLINK_SYSERR);
    TKT_PrintErr(err, acStr);
    while(1);       // instead of reset...
}

// Error Code: 001
VOID WifiInitError(VOID)
{
    OnSysError(1, "Wifi Init Error");
}

// Error Code: 002
VOID NoNetworkError(VOID)
{
    OnSysError(2, "Network Error");
}

// Error Code: 003
VOID ServerModeError(VOID)
{
    OnSysError(3, "Cannot Start Server");
}

// Error Code: 004
VOID NoMemoryError(VOID)
{
    OnSysError(4, "Low Memory");
}

// Error Code: 005
VOID NoSdCardError(VOID)
{
    OnSysError(5, "No SD Card Found");
}

// Error Code: 006
VOID FileRwError(VOID)
{
    OnSysError(6, "File RW Error");
}

// Error Code: 007
VOID NoServerFoundError(VOID)
{
    // retry connecting to server
    OnSysError(7, "No Server Error");
}

// Error Code: 008
VOID WifiResetError(VOID)
{
    OnSysError(8, "Wifi Reset");
}

// Error Code: 009
VOID NoWifiError(VOID)
{
    OnSysError(9, "No Wifi Module");
}

/*******************************************************************************
* This routine is called every BSP_MCT_INTERVAL msec
*******************************************************************************/
VOID IntervalRoutine(VOID)
{
    BTN_Scan();
    LED_Blink();
}

/*******************************************************************************
* NOTE:
*   1. Kiosk assumes that NVDS is already pre-configured with valid info
*   2. For test purposes:
*           (a) Use 1 queue for all transaction types 
*           (b) All clickers will get next transaction in the same queue
*           (c) Each clicker is associated with one display row
*           (d) 
*******************************************************************************/
VOID AppEntry(VOID)
{
    CHAR network[ROUTER_LEN+1], password[ROUTER_LEN+1];
    
    LED_Init();
    BTN_Init();
    KTRANS_Init();
    LED_StartBlink(0, LEDBLINK_STARTUP);
    
    WifiInit();
    u_strcpy_rom2ram(cRouterName, network);
    u_strcpy_rom2ram(cRouterPwd, password);
    WifiConnectToNetwork(network, password);
    
    LED_StopBlink(0);
    LED_On(1);
    TKT_PrintOnline();
    
    WifiStartListen(uiServerPort);
    
    while(1)
    {
        BTN_ExecFunc( ucBTN_GetKeyEvent() );
        KTRANS_ProcTicketRqst();
    }
}
// End of file