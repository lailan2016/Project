#include <ez8.h>
#include "eldtypes.h"

#define LED_MAXNUM      (2)     // number of LEDs

#define LED1        (0x02)
#define LED2        (0x80)
#define LED_MASK    (LED1 | LED2)

BOOL bLED_IsOn[LED_MAXNUM];
BOOL bLED_IsBlinking[LED_MAXNUM];
UINT32 ulLED_IntervalCtr[LED_MAXNUM];
UINT32 ulLED_Interval[LED_MAXNUM];

VOID LED_Init(VOID)
{
    UINT8 ctr = 0;
    
	PCDD &= ~ LED_MASK;
    PCOUT |= LED_MASK;
    
    for(ctr = 0; ctr < LED_MAXNUM; ctr++)
    {
        ulLED_Interval[ctr] = 0;
        ulLED_IntervalCtr[ctr] = 0;
        bLED_IsOn[ctr] = FALSE;
        bLED_IsBlinking[ctr] = FALSE;
    }
}

VOID LED_Toggle(UINT8 ucLedNum)
{
    UINT8 mask = 0;
    
    if(ucLedNum >= LED_MAXNUM)
        return;
    
    mask = LED1;
    if(ucLedNum == 1)
        mask = LED2;
    
	PCOUT ^= mask;
    if(bLED_IsOn[ucLedNum])
        bLED_IsOn[ucLedNum] = FALSE;
    else
        bLED_IsOn[ucLedNum] = TRUE;
}

VOID LED_Off(UINT8 ucLedNum)
{
    UINT8 mask = 0;
    
    if(ucLedNum >= LED_MAXNUM)
        return;
    
    mask = LED1;
    if(ucLedNum == 1)
        mask = LED2;
    
	PCOUT |= mask;
	bLED_IsOn[ucLedNum] = FALSE;
}

VOID LED_On(UINT8 ucLedNum)
{
    UINT8 mask = 0;
    
    if(ucLedNum >= LED_MAXNUM)
        return;
    
    mask = LED1;
    if(ucLedNum == 1)
        mask = LED2;
    
	PCOUT &= ~mask;
	bLED_IsOn[ucLedNum] = TRUE;
}

// Actual blink interval = ulInterval * MCT interval
VOID LED_StartBlink(UINT8 ucLedNum, UINT32 ulInterval)
{
    if(ucLedNum >= LED_MAXNUM)
        return;
    
    ulLED_Interval[ucLedNum] = ulInterval;
    ulLED_IntervalCtr[ucLedNum] = ulInterval;
    bLED_IsBlinking[ucLedNum] = TRUE;
    LED_On(ucLedNum);
}

VOID LED_StopBlink(UINT8 ucLedNum)
{
    ulLED_IntervalCtr[ucLedNum] = 0;
    bLED_IsBlinking[ucLedNum] = FALSE;
    LED_Off(ucLedNum);
}

VOID LED_Blink(VOID)
{
    UINT8 ctr = 0;
    
    for(ctr = 0; ctr < LED_MAXNUM; ctr++)
    {
        if(bLED_IsBlinking[ctr] && ulLED_IntervalCtr[ctr])
        {
            ulLED_IntervalCtr[ctr]--;
            if(ulLED_IntervalCtr[ctr] == 0)
            {
                LED_Toggle(ctr);
                ulLED_IntervalCtr[ctr] = ulLED_Interval[ctr];
            }
        }
    }
}
// End of file