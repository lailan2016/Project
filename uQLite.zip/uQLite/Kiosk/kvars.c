#include "eldtypes.h"
#include "kvars.h"
#include "ktrans.h"

#ifndef _DEPLOY 
rom CHAR cRouterName[ROUTER_LEN] _At APPVARS_STA_ADDR = "uQLite\0";
rom CHAR cRouterPwd[ROUTER_LEN] _At ... = "ELD2015!\0";
rom CHAR cLogoPath[FN_LEN] _At ... = "";
rom CHAR cCompanyName[COMPANY_FN_LEN] _At ... = "Bustos Water District\0";
rom CHAR cSvcList[SVCLIST_MAXNUM][STRLEN_MAX] _At ... = { 
    "Payment\0",                             
    "Customer Service",
    "Cashier\0",
    nullstr_t,
    nullstr_t,
    nullstr_t,
    nullstr_t,
    nullstr_t,
    nullstr_t,
    nullstr_t
};
rom CHAR cRmksList[RMKSLIST_MAXNUM][STRLEN_MAX] _At ... = { 
    "Completed\0",                             
    "No Show\0",
    nullstr_t,
    nullstr_t,
    nullstr_t
};
rom CHAR cServerIp[STRLEN_MAX] _At ... = "192.168.0.100\0";
rom UINT8 ucSysRmksMax _At ... = 2; 
rom UINT16 uiServerPort _At ... = 3333;
rom UINT8 ucCallerDb[SVCLIST_MAXNUM * 2] _At ... = { 
    0, 0, 0, 1, 2   
};
rom UINT8 ucReserved3[NUM_EMPTYROMSPACE] _At ...;
rom UINT8 ucMyIdRsv[5] _At ... = {0, 0, 0, 0, 0};
rom CHAR cMyDvcHdr _At ... = MY_DVC_CODE;
rom UINT16 uiMyDvcId _At ... = 2;

#else

rom CHAR cRouterName[ROUTER_LEN] _At APPVARS_STA_ADDR;
rom CHAR cRouterPwd[ROUTER_LEN] _At ...;
rom CHAR cLogoPath[FN_LEN] _At ...;
rom CHAR cCompanyName[COMPANY_FN_LEN] _At ...;
rom CHAR cSvcList[SVCLIST_MAXNUM][STRLEN_MAX] _At ...;
rom CHAR cRmksList[RMKSLIST_MAXNUM][STRLEN_MAX] _At ...;
rom CHAR cServerIp[STRLEN_MAX] _At ...;
rom UINT8 ucSysRmksMax _At ...;
rom UINT16 uiServerPort _At ...;
rom UINT8 ucCallerDb[SVCLIST_MAXNUM * 2] _At ...;
rom UINT8 ucReserved3[NUM_EMPTYROMSPACE] _At ...;
rom UINT8 ucMyIdRsv[5] _At ...;
rom CHAR cMyDvcHdr _At ...;
rom UINT16 uiMyDvcId _At ...;

#endif
// End of file