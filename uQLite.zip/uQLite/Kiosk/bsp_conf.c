#include <ez8.h>
#include "eldtypes.h"
#include "bsp_conf.h"
#include "z8mct.h"
#include "z8uart.h"
#include "z8spi.h"
#include "z8i2c.h"
#include "prntr.h"

#include "z8rtc.h"

#define BSP_MCT_MAXCHANNELS     (5)
#define BSP_MCT_INTERVAL        (5)                     // in msec

#define BSP_UART_NUMCHANNELS    (2)

#define BSP_SPI_NUMCHANNELS     (1)
#define BSP_SPI_MISO0_PC3       (1)     // Set to: (1) PC3 or (0) PC1 for MISO0
#define BSP_SPI_MOSI0_PC4       (1)     // Set to: (1) PC4 or (0) PA4 for MOSI0
#define BSP_SPI_SCK0_PC5        (1)     // Set to: (1) PC5 or (0) PA5 for SCK0

extern VOID AppEntry(VOID);     // Application main code should be AppEntry()

// from Application Layer
extern VOID IntervalRoutine(VOID);
VOID WIFI_TxHdlr(VOID);
VOID WIFI_RxHdlr(UINT8 data); 

////////////////////////////////////////////////////////////////////////////////
// MCT Configuration
////////////////////////////////////////////////////////////////////////////////
stMCTimers stMCT_Timers[BSP_MCT_MAXCHANNELS];
stMCTConfig _gMCT_Config = {
    BSP_MCT_MAXCHANNELS, BSP_MCT_INTERVAL, MCT_PRESCALE_128, INTPRIORITY_HIGH, IntervalRoutine
};

////////////////////////////////////////////////////////////////////////////////
// UART Configuration
////////////////////////////////////////////////////////////////////////////////
UINT8 _gUART_NumChannels = BSP_UART_NUMCHANNELS;
stUARTConfig _gUART_Config[BSP_UART_NUMCHANNELS] = {
    { BAUD_19200,   NOPARITY,   STOP_1, INTPRIORITY_NOMINAL,    Prntr_RxIsrHdlr,    Prntr_TxIsrHdlr },
    { BAUD_115200,  NOPARITY,   STOP_1, INTPRIORITY_HIGH,       WIFI_RxHdlr,        WIFI_TxHdlr }
};


////////////////////////////////////////////////////////////////////////////////
// RTC Configuration
////////////////////////////////////////////////////////////////////////////////
//stRTCConfig _gRTC_Config = { RTC_PRESCALE_1, RTC_FREQ_32kHz, RTC_CLK_SYSCLK };

////////////////////////////////////////////////////////////////////////////////
// SPI Configuration
////////////////////////////////////////////////////////////////////////////////
UINT8 _gSPI_NumChannels = BSP_SPI_NUMCHANNELS;
BOOL _gSPI_Miso0_UsePc3 = BSP_SPI_MISO0_PC3;
BOOL _gSPI_Mosi0_UsePc4 = BSP_SPI_MOSI0_PC4;
BOOL _gSPI_Sck0_UsePc5 = BSP_SPI_SCK0_PC5;

stSPIConfig _gSPI_Config[BSP_SPI_NUMCHANNELS] = {
    {
        SPI_DIRECTION_RXTX | SPI_TXER_MODE3 | SPI_MODE_MASTER,
        INTPRIORITY_NOMINAL, 'C', 2, nullptr_t, nullptr_t
    }
};

////////////////////////////////////////////////////////////////////////////////
// I2C Configuration
////////////////////////////////////////////////////////////////////////////////
UINT32 _gI2C_Baud = 80000;

extern VOID AppEntry(VOID);

// ORIGINALLY:
//  System Clock Init
//  Other Clock Sources Init
//  Reset, WDT, Low Power Modes Init
//  Application Timer Init (MCT)
//  All Other Peripherals Init
VOID main(VOID)
{   
    UINT16 delay = 0xFFFF;
    while(delay--);
    
    DI();
	
    do
    {
        CLKCTL0 = 0xE7;
		CLKCTL0 = 0x18;
    }while(!(CLKCTL0 & 0x80));
      
    CLKCTL2 = 0x09;             // select HFXO
    while(!(CLKCTL2 & 0x80));   // wait until ready

    CLKCTLA = 0x2F;             // configure PLL
    CLKCTLB = 0x34;
    CLKCTLC = 0x01;             // select HFXO for PLL source
    while(!(CLKCTLC & 0x80));   // wait for PLL to be ready
        
    CLKCTL0 = 0x8B;
        
    while( (CLKCTL0 & 0x07) != 0x03 );
    
    CLKCTL1 |= 0x01;              
    CLKCTL5 = 0x05;
    CLKCTL4 = 0x00;               
    CLKCTL3 = 0x7A;               
    while(!(CLKCTL5 & 0x10));       
    CLKCTL0 &= ~0x80;
    EI();
    
    MCT_Init();
    UART_Init(UART0);
    UART_Init(UART1);
    SPI_Init(ESPI0);
    I2C_Init();
    
    AppEntry();
}

// End of file