#include <ez8.h>
#include <stdlib.h>
#include "eldtypes.h"
#include "buttons.h"
#include "kvars.h"
#include "ktrans.h"

// Port bit mapping for each button
#define BTN_DISABLED    (0x0000)

#define BTNA            (0x8000)
#define BTNB            (0x4000)
#define BTNC            (0x2000)
#define BTND            (0x1000)
#define BTNE            (0x0800)
#define BTNF            (BTN_DISABLED)
#define BTNG            (BTN_DISABLED)
#define BTNJ            (BTN_DISABLED)
#define BTNK            (BTN_DISABLED)
#define BTNL            (BTN_DISABLED)

#define BTN_MASK        (BTNA | BTNB | BTNC | BTND | BTNE | BTNF | BTNG | BTNJ | BTNK | BTNL)

////////////////////////////////////////////////////////////////////////////////
// Button Press Detection
////////////////////////////////////////////////////////////////////////////////
#define MAX_CHECKS      (10)
UINT16 uiSW_DebouncedState;
UINT16 uiSW_KeyStates[MAX_CHECKS];       // 2-bytes is equivalent to states of ALL switches (1: Pressed     0:Released)
UINT8 ucSW_KeyStateIdx;
BOOL bBTN_IsBusy = TRUE;

#define SW_REACT_ON_RELEASE     (!(uiSW_DebouncedState & i) && (keyState & i))
#define SW_REACT_ON_PRESS       ((uiSW_DebouncedState & i) && !(keyState & i))

typedef struct
{
    UINT16 uiBitMsk;     // Button mask from port bit mapping
    UINT8 ucSvcIdx;     // Index number/value mapped to cSvcList
}tBTN_Map;

// Button Function Map
tBTN_Map BTN_Map[NUM_SERVICES] = {
    { BTNA,     0   },
    { BTNB,     1   },
    { BTNC,     2   }
};

////////////////////////////////////////////////////////////////////////////////
// Button Press Detection
////////////////////////////////////////////////////////////////////////////////
VOID BTN_Init(VOID)
{
    UINT8 ctr = 0;
    
    PBDD |= 0x08;
    PCDD |= 0x40;
    PDDD |= 0xC8;
    PEDD |= 0x7C;
    
    uiSW_DebouncedState = BTN_MASK;
    ucSW_KeyStateIdx = 0;
    for(ctr = 0; ctr < MAX_CHECKS; ctr++)
        uiSW_KeyStates[ctr] = BTN_MASK;
	
    bBTN_IsBusy = FALSE;
}

// updates button status
VOID BTN_Scan(VOID)
{
    UINT16 temp = 0;
    UINT8 read = 0;
	
	if(bBTN_IsBusy)
		return;
    
    // Read button states
    read = PBIN & 0x08;
    if(read & 0x08)     temp |= BTNA;
    
    read = PCIN & 0x40;
    if(read & 0x40)     temp |= BTNJ;
    
    read = PDIN & 0xC8;
    if(read & 0x80)     temp |= BTNE;
    if(read & 0x40)     temp |= BTNG;
    if(read & 0x08)     temp |= BTNK;
    
    read = PEIN & 0x7C;
    if(read & 0x40)     temp |= BTNC;
    if(read & 0x20)     temp |= BTNB;
    if(read & 0x18)     temp |= BTNL;
    if(read & 0x08)     temp |= BTNF;
    if(read & 0x04)     temp |= BTND;

    uiSW_KeyStates[ucSW_KeyStateIdx++] = temp;
    if(ucSW_KeyStateIdx >= MAX_CHECKS)
        ucSW_KeyStateIdx = 0;
}

// returns key event at the corresponding bit
UINT16 ucBTN_GetKeyEvent(VOID)
{
    UINT16 i, keyState, keyEvent = 0;
    
    keyState = BTN_MASK;
    for(i = 0; i < MAX_CHECKS; i++)
        keyState = keyState & uiSW_KeyStates[i];
    
 //   if(uiSW_DebouncedState)
    {   // one key is previously pressed
        for(i = 0x01; i > 0; i <<= 1)
        {
            if( SW_REACT_ON_PRESS )
            {
                keyEvent = i;
                keyState = i;
                break;
            }
        }
    }
    
    uiSW_DebouncedState = keyState;
    
    return keyEvent;
}

BOOL BTN_IsKeyPressed(VOID)
{
    UINT16 i, keyState = BTN_MASK;
    
    for(i = 0; i < MAX_CHECKS; i++)                 // if at least 1 button is pressed
        keyState = keyState & uiSW_KeyStates[i];    // take note of it
    
    return (keyState != BTN_MASK);
}

VOID BTN_ExecFunc(UINT16 ucKey)
{
    UINT8 idx = 0;
    
    if(!ucKey)
        return;
    
    if(bBTN_IsBusy)
        return;
    
    bBTN_IsBusy = TRUE;
    uiSW_DebouncedState &= ~ucKey;     // Consider it handled!
    
    for(idx = 0; idx < NUM_SERVICES; idx++)
    {
        if(ucKey & BTN_Map[idx].uiBitMsk)
        {
            KTRANS_GenerateTicket(BTN_Map[idx].ucSvcIdx);
            break; 
        }
    }
    
    bBTN_IsBusy = FALSE;
}
// End of file