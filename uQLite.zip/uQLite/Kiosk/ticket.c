#include <string.h>
#include <stdio.h>
#include "eldtypes.h"
#include "kvars.h"
#include "utils.h"
#include "ktrans.h"
#include "prntr.h"
#include "main.h"

VOID TKT_PrintHeader(VOID)
{
    CHAR temp[COMPANY_FN_LEN];
    UINT8 len = 0;
    
    // Print Company Name
    memset(temp, 0, COMPANY_FN_LEN);
    u_memcpy_rom2ram((rom UINT8 *)cCompanyName, (UINT8 *)temp, COMPANY_FN_LEN);
    
    PrntrSetAlignment(1);
    PrntrSetCharSize(0x00);
    PrntrPrintStr(temp);
    PrntrFeedLines(1);
}

VOID TKT_CutPaper(VOID)
{
    UINT16 i = 0;
    
    PrntrFeedLines(3);
	PRNTR_PartialCut();
	for(i = 0; i < 0xFFF; i++);
}

VOID TKT_Print(tTKTInfo tInfo)
{
    CHAR temp[COMPANY_FN_LEN];
    UINT8 len = 0;
    
    TKT_PrintHeader();
    
    // Print Ticket Number
    u_itoa(temp, 3, tInfo.uiTicketNum);
    temp[3] = 0; // add null-termination
    PrntrSetCharSize(0x44);
    PrntrPrintStr(temp);
    PrntrFeedLines(1);
    
    // Print Service Name
    memset(temp, 0, COMPANY_FN_LEN);
    u_memcpy_rom2ram((rom UINT8 *)cSvcList[tInfo.ucSvcIdx], (UINT8 *)temp, STRLEN_MAX);
    PrntrSetCharSize(0x11);
	PrntrPrintStr(temp);
    PrntrFeedLines(1);    
    
    // Print Date & Time
    memset(temp, 0, COMPANY_FN_LEN);
    len = EXTRTC_DateTimeToString('d', temp, tInfo.stStaTime);
    PrntrSetCharSize(0x00);
	PrntrPrintStr(temp);
    PrntrPrintStr("    \0");
    
    memset(temp, 0, COMPANY_FN_LEN);
    len = EXTRTC_DateTimeToString('T', temp, tInfo.stStaTime);
    PrntrPrintStr(temp);
    PrntrFeedLines(1);
    
    TKT_CutPaper();
}

VOID TKT_PrintOnline(VOID)
{
    TKT_PrintHeader();
    
    PrntrPrintStr("System Online\0");
    PrntrFeedLines(1);
    
    TKT_CutPaper();
}

VOID TKT_PrintErr(UINT16 err, CHAR *acStr)
{
    CHAR temp[COMPANY_FN_LEN];
    UINT8 len = 0;
    
    TKT_PrintHeader();
    
    // Print Error Number
    len = u_strcpy("ERROR (\0", temp);
    
    u_itoa(&temp[len], 3, (UINT16)err);
    len += 3;
    
    len += u_strcpy("): \0", &temp[len]);
    len += u_strcpy(acStr, &temp[len]);
    
    PrntrPrintStr(temp);
    PrntrFeedLines(1);
    
	TKT_CutPaper();
}

// End of file