#ifndef __LED_H__
#define __LED_H__

VOID LED_Init(VOID);
VOID LED_Toggle(UINT8 ucLedNum);
VOID LED_Off(UINT8 ucLedNum);
VOID LED_On(UINT8 ucLedNum);
VOID LED_StartBlink(UINT8 ucLedNum, UINT32 ulInterval);
VOID LED_StopBlink(UINT8 ucLedNum);
VOID LED_Blink(VOID);

#endif // __LED_H__
// End of file