#ifndef __LED_H__
#define __LED_H__

VOID LED_Init(VOID);
VOID LED_Toggle(VOID);
VOID LED_Off(VOID);
VOID LED_On(VOID);
VOID LED_StartBlink(UINT32 ulInterval);
VOID LED_StopBlink(VOID);
VOID LED_Blink(VOID);

#endif // __LED_H__
// End of file