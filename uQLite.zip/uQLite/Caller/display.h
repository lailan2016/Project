#ifndef __DISPLAY_H__
#define __DISPLAY_H__

// LCD Wrapper Routines
VOID ShowWelcome(VOID);
VOID DISP_Connecting(VOID);
VOID DISP_Offline(VOID);
VOID DISP_Online(VOID);
VOID DISP_Main(VOID);

VOID ShowTicket(rom CHAR *strService, CHAR *ticketNum);

VOID DISP_Requesting(VOID);
VOID DISP_ClearRequesting(VOID);
VOID ShowSelection(rom CHAR *strSelection, UINT8 strLen, BOOL showHeader);

VOID DISP_DeviceConfig(VOID);
VOID DISP_SysErr(UINT16 uiErr);
VOID ShowService(rom CHAR *strService);

#endif // __DISPLAY_H__
// End of file