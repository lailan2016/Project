#include <stdlib.h>     // atoi
#include <string.h>     // memset
#include "eldtypes.h"
#include "tcp.h"
#include "esp11.h"
#include "cvars.h"
#include "utils.h"

CHAR strCurrTicket[TCP_TKTNUM_LEN] = "0000";
CHAR RequestMsg[RQSTMSG_LEN+1];     // plus 1 to account for null-termination

#define TRANSTATE_IDLE      (0)
#define TRANSTATE_SERVICING (1)

UINT8 TranState = TRANSTATE_IDLE;

VOID CreateRequest(CHAR toDvcHdr, UINT16 toDvcId, CHAR rqstId, UINT8 remarksId)
{
    CHAR *msg;
    
    memset(RequestMsg, 0, RQSTMSG_LEN);
    msg = RequestMsg;
    
    *msg++ = TCP_PROT_SOF;
    
    *msg++ = MY_DVC_CODE;
    u_itoa(msg, TCP_DVCID_LEN - 1, uiMyDvcId);
    msg += TCP_DVCID_LEN - 1;
    *msg++ = TCP_PROT_SEPARATOR;
    
    *msg++ = toDvcHdr;
    u_itoa(msg, TCP_DVCID_LEN - 1, toDvcId);
    msg += TCP_DVCID_LEN - 1;
    *msg++ = TCP_PROT_SEPARATOR;
    
    *msg++ = rqstId;
    *msg++ = TCP_PROT_SEPARATOR;
    
    u_memcpy((UINT8 *)strCurrTicket, (UINT8 *)msg, TCP_TKTNUM_LEN);
    msg += TCP_TKTNUM_LEN;
    *msg++ = TCP_PROT_SEPARATOR;
    
    u_itoa(msg, TCP_RMKS_LEN, remarksId);
    msg += TCP_RMKS_LEN;
    
    *msg++ = TCP_PROT_EOF;
    *msg = 0;
}

BOOL ParseResponse(CHAR *strMsg, TcpResponse *respMsg)
{
    if(*strMsg++ == TCP_PROT_SOF)
    {
        respMsg->FromDeviceHeader = *strMsg++;
        respMsg->FromDeviceId = u_atoi(strMsg, TCP_DVCID_LEN - 1);
        strMsg += TCP_DVCID_LEN;
        
        respMsg->ToDeviceHeader = *strMsg++;
        respMsg->ToDeviceId = u_atoi(strMsg, TCP_DVCID_LEN - 1);
        strMsg += TCP_DVCID_LEN;
        
        respMsg->ServiceIdx = u_atoi(strMsg, TCP_SVCIDX_LEN);
        strMsg += TCP_SVCIDX_LEN + 1;
        
        u_memcpy((UINT8 *)strMsg, (UINT8 *)respMsg->TicketNum, TCP_TKTNUM_LEN);
        
        if( (respMsg->ToDeviceHeader == MY_DVC_CODE) &&
            (respMsg->ToDeviceId == uiMyDvcId) &&
            (respMsg->ServiceIdx < ucSysSvcMax) )
        {
            return TRUE;
        }
    }
    
    return FALSE;
}

BOOL TransactWithKiosk(tServerInfo server, TcpResponse *tResp, UINT8 retries)
{
    CHAR replyMsg[RESPMSG_LEN];
    UINT8 numTries = 0;
    BOOL msgOkay = FALSE;
    
    memset(replyMsg, 0, RESPMSG_LEN);
    do
    {
        WifiConnectToServer(server);
        WifiSendString(RequestMsg, RQSTMSG_LEN, server);
        if( WifiGetString(replyMsg) )
        {
            if( ParseResponse(replyMsg, tResp) )
            {
                msgOkay = TRUE;
                WifiDisconnectFromServer();
                return msgOkay;
            }
        }
        WifiDisconnectFromServer();
        numTries++;
    }
    while(numTries < retries);
        
    return msgOkay;
}

UINT8 ExecuteCall(CHAR *ticketNum)
{
    tServerInfo server;
    TcpResponse resp;
    
    if(TranState != TRANSTATE_IDLE)
        return FALSE;
    
    CreateRequest(KIOSK_DVC_CODE, uiSrvrDvcId, TCP_RQSTID_CALL, ucWdwNum);
    u_strcpy_rom2ram(cServerIp, server.IpAddress);
    server.Port = uiServerPort;
    if( TransactWithKiosk(server, &resp, 3) )
    {
        if( (resp.TicketNum[0] != '0') || (resp.TicketNum[1] != '0') ||
            (resp.TicketNum[2] != '0') || (resp.TicketNum[3] != '0') )
        {
            u_memcpy((UINT8 *)resp.TicketNum, (UINT8 *)strCurrTicket, TCP_TKTNUM_LEN);
            u_memcpy((UINT8*)resp.TicketNum, (UINT8*)ticketNum, TCP_TKTNUM_LEN);
            TranState = TRANSTATE_SERVICING;
            return TRUE;
        }
    }
    
    return FALSE;
}

VOID ExecRecall(VOID)
{
    tServerInfo server;
    TcpResponse resp;
    
    if(TranState != TRANSTATE_SERVICING)
        return;
    
    CreateRequest(DISPLAY_DVC_CODE, uiDispDvcId, TCP_RQSTID_DISPLAY, ucWdwNum);
    u_strcpy_rom2ram(cDisplayIp, server.IpAddress);
    server.Port = uiDisplayPort;
    (VOID)TransactWithKiosk(server, &resp, 1);
}

VOID ExecDone(UINT8 remarksIdx)
{
    tServerInfo server;
    TcpResponse resp;
    
    if(TranState != TRANSTATE_SERVICING)
        return;
    
    CreateRequest(KIOSK_DVC_CODE, uiSrvrDvcId, TCP_RQSTID_DONE, remarksIdx);
    u_strcpy_rom2ram(cServerIp, server.IpAddress);
    server.Port = uiServerPort;
    (VOID)TransactWithKiosk(server, &resp, 3);
    memset(strCurrTicket, '0', TCP_TKTNUM_LEN);
    TranState = TRANSTATE_IDLE;
}

VOID ExecTxer(UINT8 serviceIdx)
{
    tServerInfo server;
    TcpResponse resp;
    
    if(TranState != TRANSTATE_SERVICING)
        return;
    
    CreateRequest(KIOSK_DVC_CODE, uiSrvrDvcId, TCP_RQSTID_TXER, serviceIdx);
    u_strcpy_rom2ram(cServerIp, server.IpAddress);
    server.Port = uiServerPort;
    (VOID)TransactWithKiosk(server, &resp, 3);
    memset(strCurrTicket, '0', TCP_TKTNUM_LEN);
    TranState = TRANSTATE_IDLE;
}
// End of file