#include "eldtypes.h"
#include "cvars.h"

CHAR cFirmwareVersion[] = FIRMWARE_VERSION;

// Flash Offset Map
tAPPVARS_Map APPVARS_Map[APPVARS_MAXVARS] = {
	{ "usr\0", 	    0x0000,     VARTYPE_STRING, STRLEN_MAX },

	{ "svc01\0", 	0x0010,     VARTYPE_STRING, STRLEN_MAX },
	{ "svc02\0", 	0x0020,     VARTYPE_STRING, STRLEN_MAX },
	{ "svc03\0", 	0x0030,     VARTYPE_STRING, STRLEN_MAX },
	{ "svc04\0", 	0x0040,     VARTYPE_STRING, STRLEN_MAX },
	{ "svc05\0", 	0x0050,     VARTYPE_STRING, STRLEN_MAX },
	{ "svc06\0", 	0x0060,     VARTYPE_STRING, STRLEN_MAX },
	{ "svc07\0", 	0x0070,     VARTYPE_STRING, STRLEN_MAX },
	{ "svc08\0", 	0x0080,     VARTYPE_STRING, STRLEN_MAX },
	{ "svc09\0", 	0x0090,     VARTYPE_STRING, STRLEN_MAX },
	{ "svc10\0", 	0x00A0,     VARTYPE_STRING, STRLEN_MAX },
	{ "svc11\0", 	0x00B0,     VARTYPE_STRING, STRLEN_MAX },
	{ "svc12\0", 	0x00C0,     VARTYPE_STRING, STRLEN_MAX },

	{ "rmk01\0", 	0x00D0,     VARTYPE_STRING, STRLEN_MAX },
	{ "rmk02\0", 	0x00E0,     VARTYPE_STRING, STRLEN_MAX },
	{ "rmk03\0", 	0x00F0,     VARTYPE_STRING, STRLEN_MAX },
	{ "rmk04\0", 	0x0100,     VARTYPE_STRING, STRLEN_MAX },
	{ "rmk05\0", 	0x0110,     VARTYPE_STRING, STRLEN_MAX },
	{ "rmk06\0", 	0x0120,     VARTYPE_STRING, STRLEN_MAX },
	{ "rmk07\0", 	0x0130,     VARTYPE_STRING, STRLEN_MAX },
	{ "rmk08\0", 	0x0140,     VARTYPE_STRING, STRLEN_MAX },
	{ "rmk09\0", 	0x0150,     VARTYPE_STRING, STRLEN_MAX },
	{ "rmk10\0", 	0x0160,     VARTYPE_STRING, STRLEN_MAX },

	{ "ssid\0",	    0x0170,     VARTYPE_STRING, ROUTER_LEN },
	{ "spwd\0", 	0x0180,     VARTYPE_STRING, ROUTER_LEN },
	{ "kip\0", 	    0x0190,     VARTYPE_STRING, STRLEN_MAX },
	{ "sip\0", 	    0x01A0,     VARTYPE_STRING, STRLEN_MAX },

	{ "mysvcid\0", 	0x01E0,     VARTYPE_BYTE,   1 },
	{ "svcmax\0",   0x01E1,     VARTYPE_BYTE,   1 },
	{ "rmksmax\0",  0x01E2,     VARTYPE_BYTE,   1 },
	{ "kport\0",    0x01E3,     VARTYPE_SHORT,  2 },
    { "wdw\0",      0x01E5,     VARTYPE_BYTE,   1 },
};


rom CHAR cMyUserName[STRLEN_MAX]  _At APPVARS_STA_ADDR = "   Counter X   \0"; 
rom CHAR cSvcList[SVCLIST_MAXNUM][STRLEN_MAX] _At ... = {  
    "Payment\0",                             
    "Customer Service",
    "Cashier\0",
    nullstr_t,
    nullstr_t,
    nullstr_t,
    nullstr_t,
    nullstr_t,
    nullstr_t,
    nullstr_t,
    nullstr_t,
    nullstr_t,
};
rom CHAR cRmksList[RMKSLIST_MAXNUM][STRLEN_MAX] _At ... = { 
    "Completed      \0",                             
    "No Show        \0",
    nullstr_t,
    nullstr_t,
    nullstr_t,
    nullstr_t,
    nullstr_t,
    nullstr_t,
    nullstr_t,
    nullstr_t,
};
rom CHAR cRouterName[ROUTER_LEN] _At ... = "uQLite\0";
rom CHAR cRouterPwd[ROUTER_LEN] _At ... = "ELD2015!\0";
rom CHAR cServerIp[STRLEN_MAX] _At ... = "192.168.0.100\0";
rom CHAR cDisplayIp[STRLEN_MAX] _At ... = "192.168.0.101\0";
rom UINT8 ucReserved1[48] _At ...;

rom UINT8 ucMySvcId _At ... = 0; 
rom UINT8 ucSysSvcMax _At ... = 3;
rom UINT8 ucSysRmksMax _At ... = 2;
rom UINT16 uiServerPort _At ... = 3333;
rom UINT8 ucWdwNum _At ... = 5;
rom UINT16 uiDisplayPort _At ... = 3334;

rom UINT8 ucDispIdRsv[5] _At ... = {0, 0, 0, 0, 0};
rom CHAR cDispDvcHdr _At ... = DISPLAY_DVC_CODE;
rom UINT16 uiDispDvcId _At ... = 1001;

rom UINT8 ucSrvrIdRsv[5] _At ... = {0, 0, 0, 0, 0};
rom CHAR cSrvrDvcHdr _At ... = KIOSK_DVC_CODE;
rom UINT16 uiSrvrDvcId _At ... = 2;

rom UINT8 ucMyIdRsv[5] _At ... = {0, 0, 0, 0, 0};
rom CHAR cMyDvcHdr _At ... = MY_DVC_CODE;
rom UINT16 uiMyDvcId _At ... = 2011;


// End of file