#ifndef __LCD_H__
#define __LCD_H__

#include <ez8.h>
#include <defines.h>

#define BIT0        (0x01)
#define BIT1        (0x02)
#define BIT2        (0x04)
#define BIT3        (0x08)
#define BIT4        (0x10)
#define BIT5        (0x20)
#define BIT6        (0x40)
#define BIT7        (0x80)

// Requires DB[4:7] be located at Px[4:7] in proper sequence
#define LCD_DB_IN               (PBIN)
#define LCD_DB_IO_SET           (PBDD)

#define LCD_DB_OUT              (PBOUT)
#define LCD_DB_4                (BIT0)
#define LCD_DB_5                (BIT1)
#define LCD_DB_6                (BIT2)
#define LCD_DB_7                (BIT3)
#define LCD_DB_IO_MASK          (LCD_DB_4 | LCD_DB_5 | LCD_DB_6 | LCD_DB_7)

// Requires RS, RW, EN be located at the same port
#define LCD_CTRL_IO_SET         (PCDD)

#define LCD_CTRL_OUT            (PCOUT)
#define LCD_CTRL_RS             (BIT0)
#define LCD_CTRL_RW             (BIT1)
#define LCD_CTRL_EN             (BIT2)
#define LCD_CTRL_MASK           (LCD_CTRL_RS | LCD_CTRL_RW | LCD_CTRL_EN)



/////////////////////////////////////////////////////////////////////////////////
//  LCD Control Lines Definition
//
//  PC0 = RS  (0 = command and 1 = data)
//  PC1 = R/W (0 = write and 1 = read) 
//  PC2 = E   (0 = clear enable line and 1 = set enable line)
/////////////////////////////////////////////////////////////////////////////////
#define LCD_WRITE_COMMAND       LCD_CTRL_OUT &= ~LCD_CTRL_MASK; LCD_DB_OUT &= ~LCD_DB_IO_MASK
#define LCD_WRITE_DATA          LCD_WRITE_COMMAND; LCD_CTRL_OUT |= LCD_CTRL_RS
#define LCD_READ_COMMAND        LCD_WRITE_COMMAND; LCD_CTRL_OUT |= LCD_CTRL_RW
#define SET_ENABLE              LCD_CTRL_OUT |= LCD_CTRL_EN
#define CLEAR_ENABLE            LCD_CTRL_OUT &= ~LCD_CTRL_EN


/////////////////////////////////////////////////////////////////////////////////
//  LCD display lines definition
//
//  this is used for 4 lines x 20 columns LCD 
/////////////////////////////////////////////////////////////////////////////////
#define LCD_LINE_1          0x00    
#define LCD_LINE_2          0x40
#define LCD_LINE_3          0x14
#define LCD_LINE_4          0x54

/////////////////////////////////////////////////////////////////////////////////
//  LCD driver prototypes 
/////////////////////////////////////////////////////////////////////////////////
void LCD_init (void);
void LCD_checkBusyFlag (void);
void LCD_initCommand (UCHAR ucInitCommand);
void LCD_command (UCHAR ucCommand);
void LCD_writeNibbleData (UCHAR ucNibbleData);
void LCD_writeData (UCHAR ucData);
void LCD_setCursor_Pos (UCHAR ucRow, UCHAR ucColumn);

void LCD_printC (UCHAR ucCharacter);
void LCD_printS (CHAR *stringChar);

VOID LCD_copymap (unsigned char *bitmap);

/*void LCD_scrlLongText (CHAR *cLongText);
void LCD_scrollShort (char *long_text);
*/
/////////////////////////////////////////////////////////////////////////////////
//  LCD command/s macro
/////////////////////////////////////////////////////////////////////////////////
#define LCD_OFF				LCD_command(0x08)
#define LCD_ON				LCD_command(0x0C)
#define LCD_CLS				LCD_command(0x01)
#define LCD_CURSOR_OFF		LCD_command(0x0C)
#define LCD_CURSOR_ON		LCD_command(0x0E)
#define LCD_CURSOR_BLINK	LCD_command(0x0D)
#define LCD_HOME			LCD_command(0x02); LCD_CURSOR_BLINK

#define LCD_SET_DDRAM(addr)	LCD_command(0x80 | addr)
#define LCD_SET_CGRAM(addr)	LCD_command(0x40 | addr)

#endif	// __LCD_H__
