#ifndef __CVARS_H__
#define __CVARS_H__

#include "appvars.h"

#define MY_DVC_CODE         CALLER_DVC_CODE
#define APPVARS_MAXVARS         (32)


extern rom CHAR cMyUserName[STRLEN_MAX];
extern rom CHAR cSvcList[SVCLIST_MAXNUM][STRLEN_MAX];
extern rom CHAR cRmksList[RMKSLIST_MAXNUM][STRLEN_MAX];
extern rom CHAR cRouterName[ROUTER_LEN];
extern rom CHAR cRouterPwd[ROUTER_LEN];
extern rom CHAR cServerIp[STRLEN_MAX];
extern rom CHAR cDisplayIp[STRLEN_MAX];
//extern rom UINT8 ucReserved1[48];
extern rom UINT8 ucMySvcId;
extern rom UINT8 ucSysSvcMax;
extern rom UINT8 ucSysRmksMax;
extern rom UINT16 uiServerPort;
extern rom UINT8 ucWdwNum;
extern rom UINT16 uiDisplayPort;
//extern rom UINT8 ucDispIdRsv[5];
extern rom CHAR cDispDvcHdr;
extern rom UINT16 uiDispDvcId;
//extern rom UINT8 ucSrvrIdRsv[5];
extern rom CHAR cSrvrDvcHdr;
extern rom UINT16 uiSrvrDvcId;
//extern rom UINT8 ucMyIdRsv[5];
extern rom CHAR cMyDvcHdr;
extern rom UINT16 uiMyDvcId;

#endif // __CVARS_H__