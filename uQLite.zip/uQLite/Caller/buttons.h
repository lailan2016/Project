#ifndef __BUTTONS_H__
#define __BUTTONS_H__

    
// Function Prototypes -- Button Press Detection
VOID BtnInit(VOID);
VOID BtnScan(VOID);	// must be called every 5msec
UINT8 BtnGetEvent(VOID);
BOOL IsBtnPressed(VOID);
VOID Btn_OnPressEvent(UINT8 btnEvent);

#endif // __BUTTONS_H__
// End of file