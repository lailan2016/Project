#include "eldtypes.h"
#include "lcd.h"
#include "main.h"       // TIMEOUT_LCD
#include "z8mct.h"      // MCT

////////////////////////////////////////////////////////////////////////////////
// TODO:  Cleanup & comment accordingly
////////////////////////////////////////////////////////////////////////////////
UINT8 char_map[64]	=	
	{
		0x0F,0x0F,0x0F,0x0F,0x0F,0x0F,0x0F,0x00,
		0x00,0x0F,0x0F,0x0F,0x0F,0x0F,0x0F,0x00,
		0x00,0x00,0x0F,0x0F,0x0F,0x0F,0x0F,0x00,
		0x00,0x00,0x00,0x0F,0x0F,0x0F,0x0F,0x00,
		0x00,0x00,0x00,0x00,0x0F,0x0F,0x0F,0x00,
		0x00,0x00,0x00,0x00,0x00,0x0F,0x0F,0x00,
		0x00,0x00,0x00,0x00,0x00,0x00,0x0F,0x00,
		0x0F,0x00,0x00,0x00,0x00,0x00,0x0F,0x00
	};
	
UINT8 ucLCD_MctCh = 0;
                                 
VOID Timer0_delaymsec(UINT16 msec)
{
    UINT16 delay = 1;
    
    if(msec >= TIMEOUT_LCD)
        delay = (UINT16)(msec / TIMEOUT_LCD);
    
    MCT_StartTimer(ucLCD_MctCh);
    while(delay)
    {
        if(bMCT_IsTimeout(ucLCD_MctCh))
        {
            delay--;
        }
    }
    MCT_StopTimer(ucLCD_MctCh);
}

/////////////////////////////////////////////////////////////////////////////////
//  Routine:
//      LCD_init
//  Parameters:
//		VOID
//  Return:
//      VOID
//  Description:
//      This function initializes the LCD
/////////////////////////////////////////////////////////////////////////////////                                 
VOID LCD_init (VOID)
{   
    LCD_DB_IO_SET = ~LCD_DB_IO_MASK;
    LCD_DB_OUT &= ~LCD_DB_IO_MASK;
    
    LCD_CTRL_IO_SET = ~LCD_CTRL_MASK;
    LCD_CTRL_OUT = ~LCD_CTRL_MASK;
        
    ucLCD_MctCh = MCT_AddTimer(TIMEOUT_LCD);
    
    Timer0_delaymsec(20);               //  20msec delay (more than 15msec is required)
    LCD_initCommand (0x30);             //  function set command: 8-bit mode interface
    
    Timer0_delaymsec(5);                //  5msec delay (more than 4.1msec is required)  
    LCD_initCommand (0x30);             //  function set command: 8-bit mode interface
    
    Timer0_delaymsec(1);                //  1msec delay (more than 100usec is required)                                      
    LCD_initCommand (0x30);             //  function set command: 8-bit mode interface
    
    LCD_initCommand (0x20);             //  function set command: 4-bit mode interface
    LCD_command (0x28);                 //  function set command: 4-bit mode, 2 lines, 5x7 char matrix
    LCD_command (0x08);                 //  display control commnad: display OFF, cursor OFF, cursor blink OFF
    LCD_command (0x01);                 //  clear display command 
    LCD_command (0x06);                 //  entry mode set command: increment cursor move 
    LCD_command (0x0C);                 //  display control commnad: display ON, cursor ON, cursor blink ON
}

/////////////////////////////////////////////////////////////////////////////////
//  Routine:
//      LCD_checkBusyFlag
//  Parameters:
//		VOID
//  Return:
//      VOID
//  Description:
//      This function reads LCD Busy Flag until it becomes logic 0
/////////////////////////////////////////////////////////////////////////////////             
VOID LCD_checkBusyFlag (VOID)
{
    LCD_READ_COMMAND;           //  clear LCD RS and Enable lines. set LCD R/W line. 
    Timer0_delaymsec(1);        //  1msec delay 
    while (LCD_DB_IN & 0x80)         //  check D7 of LCD data line. perform this until it becomes logic 0
    {
        SET_ENABLE;             //  set LCD Enable line
        Timer0_delaymsec(1);    //  1msec delay (minimum of 0.45usec)
        //asm("nop");
        //asm("nop");
        //asm("nop");
        //asm("nop");
        //asm("nop");
        //asm("nop");
        CLEAR_ENABLE;           //  clear LCD Enable line
    }
}

/////////////////////////////////////////////////////////////////////////////////
//  Routine:
//      LCD_initCommand
//  Parameters:
//		ucInitCommand
//  Return:
//      VOID
//  Description:
//      This function receives command and then sends to D[7:4] of the LCD 
/////////////////////////////////////////////////////////////////////////////////
VOID LCD_initCommand (UCHAR ucInitCommand)
{
    ucInitCommand >>= 4;
    
    LCD_checkBusyFlag();                //  check LCD Busy Flag
    LCD_WRITE_COMMAND;          //  clear LCD RS, R/W and Enable lines
    SET_ENABLE;                //  set LCD Enable line
    LCD_DB_OUT |= ucInitCommand;              //  sends command to LCD
    CLEAR_ENABLE;              //  clear LCD Enable line
}

/////////////////////////////////////////////////////////////////////////////////
//  Routine:
//      LCD_initCommand
//  Parameters:
//		ucInitCommand
//  Return:
//      VOID
//  Description:
//      This function receives 8-bit command. Sends first the upper nibble of the 
//      received command to LCD, then the lower nibble.
/////////////////////////////////////////////////////////////////////////////////
VOID LCD_command (UCHAR ucCommand)
{
    UCHAR ucCmd_UpperNibble = 0;                        //  prepare 8-bit storage for the upper nibble of the command
    UCHAR ucCmd_LowerNibble = 0;                        //  prepare 8-bit storage for the lower nibble of the command
    ucCmd_UpperNibble = ucCommand & 0xF0;               //  extract the upper nibble of the command
    ucCmd_LowerNibble = (ucCommand << 4) & 0xF0;        //  extract the lower nibble of the command
    LCD_initCommand (ucCmd_UpperNibble);                //  send upper nibble command to LCD        
    LCD_initCommand (ucCmd_LowerNibble);                //  send lower nibble command to LCD
}

/////////////////////////////////////////////////////////////////////////////////
//  Routine:
//      LCD_writeNibbleData
//  Parameters:
//		ucNibbleData
//  Return:
//      VOID
//  Description:
//      This function receives data and sends D[7:4] of it to LCD
/////////////////////////////////////////////////////////////////////////////////
VOID LCD_writeNibbleData (UCHAR ucNibbleData)
{
    ucNibbleData >>= 4;
    
    LCD_checkBusyFlag();                                  
    LCD_WRITE_DATA;
    SET_ENABLE;
    LCD_DB_OUT |= ucNibbleData;
    CLEAR_ENABLE;  
}

/////////////////////////////////////////////////////////////////////////////////
//  Routine:
//      LCD_writeData
//  Parameters:
//		ucData
//  Return:
//      VOID
//  Description:
//      This function receives 8-bit data. Sends first the upper nibble of the 
//      received data to LCD, then the lower nibble.
/////////////////////////////////////////////////////////////////////////////////
VOID LCD_writeData (UCHAR ucData)
{
    UCHAR ucData_UpperNibble = 0;                       //  prepare 8-bit storage for the upper nibble of the data
    UCHAR ucData_LowerNibble =0;                        //  prepare 8-bit storage for the lower nibble of the data
    ucData_UpperNibble = ucData & 0xF0;                 //  extract upper nibble of the data
    ucData_LowerNibble = (ucData << 4) & 0xF0;          //  extract lower nibble of the data
    LCD_writeNibbleData (ucData_UpperNibble);           //  send upper nibble data to LCD    
    LCD_writeNibbleData (ucData_LowerNibble);           //  send lower nibble data to LCD
}

/////////////////////////////////////////////////////////////////////////////////
//  Routine:
//      LCD_setCursor_Pos
//  Parameters:
//		ucRow (values are 0 to 3)
//      ucColumn (values are 0 to 0x13)
//  Return:
//      VOID
//  Description:
//      This function sets cursor position based on received row and column values
/////////////////////////////////////////////////////////////////////////////////
VOID LCD_setCursor_Pos (UCHAR ucRow, UCHAR ucColumn)
{
    UCHAR ucCursor_Pos = 0;                         //  prepare storage for 8-bit data
    switch (ucRow)                                  //  check the received value for row
    {
    case 0:                                         //  if row is 0...    
        ucCursor_Pos = LCD_LINE_1 + ucColumn;       //  ...it is for LCD line1. combine line1 data to column to get DDRAM address     
        break;
    case 1:                                         //  if row is 1...
        ucCursor_Pos = LCD_LINE_2 + ucColumn;       //  ...it is for LCD line2. combine line2 data to column to get DDRAM address
        break;
    case 2:                                         //  if row is 2...
        ucCursor_Pos = LCD_LINE_3 + ucColumn;       //  ...it is for LCD line3. combine line3 data to column to get DDRAM address
        break;
    case 3:                                         //  if row is 3...
        ucCursor_Pos = LCD_LINE_4 + ucColumn;       //  ...it is for LCD line4. combine line4 data to column to get DDRAM address
        break;
    default:
        break;
    }
    LCD_SET_DDRAM (ucCursor_Pos);                   //  set DDRAM address
}

/////////////////////////////////////////////////////////////////////////////////
//  Routine:
//      LCD_printC
//  Parameters:
//		ucCharacter
//  Return:
//      VOID
//  Description:
//      This function displays a character at cursor position
///////////////////////////////////////////////////////////////////////////////// 
VOID LCD_printC (UCHAR ucCharacter)
{
      LCD_writeData (ucCharacter);
}

/////////////////////////////////////////////////////////////////////////////////
//  Routine:
//      LCD_printS
//  Parameters:
//		stringChar
//  Return:
//      VOID
//  Description:
//      This function displays string of characters starting at cursor position
/////////////////////////////////////////////////////////////////////////////////
VOID LCD_printS (CHAR *stringChar)
{
    while (*stringChar)
    {
        LCD_writeData (*stringChar++);
    }
}

VOID LCD_copymap (UINT8 *bitmap)
{
	UINT8 counter = 64;
	LCD_SET_CGRAM(0);
	while (counter--)
		LCD_writeData(*bitmap++);
}

/*
/////////////////////////////////////////////////////////////////////////////////
//  Routine:
//      LCD_scrlLongText
//  Parameters:
//		ucCharacter
//  Return:
//      VOID
//  Description:
//      This function displays string of characters starting at cursor position
/////////////////////////////////////////////////////////////////////////////////
VOID LCD_scrlLongText (CHAR *cLongText)
{
	UINT16 count ;
    UINT8 columns = 20;
    UINT8 rows = 4;
	
    LCD_CURSOR_OFF;
    while (*cLongText != nullstr_t)
	{
		count = 0 ;
		LCD_CLS;
        LCD_SET_DDRAM (0x40);
		while ((count < columns) && (*cLongText != nullstr_t))
		{
			LCD_printC(*cLongText++);
			count++ ;
		}
		cLongText -= 19 ;
        Timer0_delaymsec(200);
	}
     
}

VOID LCD_scrollShort (char *long_text)
{
	UINT16 cntr;
	UINT8 screen = 0;
    UINT8 x=0;
    UINT8 position = 0x53;
    UINT16 count=0 ;
    UINT8 columns = 20;
    UINT8 rows = 4;
    LCD_CURSOR_OFF;
    screen = position - 0x40;
	
    while ((count < columns) && (*long_text != nullstr_t))
    {
        *long_text++;
        count++;
    }
    x = count;
	
    while (count < columns)
    {
		*long_text = 0x20;
        *long_text++;
        count++;
    }
	
    long_text = long_text - count ;
    while (screen)
	{
		count = 0 ;

		LCD_CLS;
        LCD_SET_DDRAM (--position);
		while (count < x) 
		{
            LCD_printC(*long_text++);
			count++ ;
		}
		long_text -= count;  
		screen--;
        
		for (cntr=0; cntr < 0xFFFF; cntr++);
		for (cntr=0; cntr < 0xFFFF; cntr++);
	} 
	
	screen = 20;
    while (screen)
	{
		count = 0 ;

		LCD_CLS;
		LCD_SET_DDRAM (0x40); // line #
		while (count < columns) 
		{
            LCD_printC(*long_text++);
			count++ ;
		}
        
        if (position == 0x40)
        {
			long_text -= 19 ;
        }
		screen--;
        Timer0_delaymsec (200);
	} 
	
    Timer0_delaymsec (200);
}*/
// End of file