#ifndef __CTRANS_H__
#define __CTRANS_H__

#include "eldtypes.h"

UINT8 ExecuteCall(CHAR *auiTicketNum);
VOID ExecRecall(VOID);
VOID ExecDone(UINT8 remarksIdx);
VOID ExecTxer(UINT8 serviceIdx);

#endif // __CTRANS_H__
// End of file