#include <ez8.h>
#include "eldtypes.h"
#include "led.h"
#include "main.h"

BOOL bLED_IsOn = FALSE;
BOOL bLED_IsBlinking = FALSE;
UINT32 ulLED_IntervalCtr = 0;
UINT32 ulLED_Interval = 0;

VOID LED_Init(VOID)
{
	PDDD &= ~0x80;
    PDOUT &= ~0x80;
    
    ulLED_Interval = 0;
    ulLED_IntervalCtr = 0;
	bLED_IsOn = FALSE;
    bLED_IsBlinking = FALSE;
}

VOID LED_Toggle(VOID)
{
	PDOUT ^= 0x80;
    if(bLED_IsOn)
        bLED_IsOn = FALSE;
    else
        bLED_IsOn = TRUE;
}

VOID LED_Off(VOID)
{
	PDOUT &= ~0x80;
	bLED_IsOn = FALSE;
}

VOID LED_On(VOID)
{
	PDOUT |= 0x80;
	bLED_IsOn = TRUE;
}

// Actual blink interval = ulInterval * MCT interval
VOID LED_StartBlink(UINT32 ulInterval)
{
    ulLED_Interval = ulInterval;
    ulLED_IntervalCtr = ulInterval;
    bLED_IsBlinking = TRUE;
    LED_On();
}

VOID LED_StopBlink(VOID)
{
    ulLED_IntervalCtr = 0;
    bLED_IsBlinking = FALSE;
    LED_Off();
}

VOID LED_Blink(VOID)
{
    if(bLED_IsBlinking && ulLED_IntervalCtr)
    {
        ulLED_IntervalCtr--;
        if(ulLED_IntervalCtr == 0)
        {
            LED_Toggle();
            ulLED_IntervalCtr = ulLED_Interval;
        }
    }
}
// End of file