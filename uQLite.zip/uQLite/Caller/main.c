#include <ez8.h>
#include <stdlib.h>
#include "eldtypes.h"
#include "z8rtc.h"
#include "z8mct.h"
#include "lcd.h"
#include "main.h"

#include "led.h"
#include "display.h"
#include "esp11.h"
#include "cvars.h"
#include "buttons.h"
#include "utils.h"

////////////////////////////////////////////////////////////////////////////////
// Designed and Tested for Z8F6481
////////////////////////////////////////////////////////////////////////////////
UINT8 ucMAIN_MctCh = 0;
UINT8 ucUSB_MctCh = 0;

VOID IntervalRoutine(VOID)
{
    BtnScan();
    LED_Blink();
}

VOID OnSysError(UINT8 err)
{
    LED_StartBlink(LEDBLINK_SYSERR);
    DISP_SysErr(err);
    
    while(1); 
}

VOID AppEntry(VOID)
{
    UINT8 retries = 0;
    UINT8 keyevt = 0;
    tServerInfo server;
    CHAR network[ROUTER_LEN+1], password[ROUTER_LEN+1];
    
    ucMAIN_MctCh = MCT_AddTimer(TIMEOUT_MAIN);
    ucUSB_MctCh = MCT_AddTimer(TIMEOUT_USB);
    
    LED_Init();     // Peripheral + Module
    LED_StartBlink(LEDBLINK_STARTUP);
    
	BtnInit();
    LCD_init();     // Peripheral + Module
    ShowWelcome();   

    WifiInit();
    
    DISP_Connecting();
    
    u_strcpy_rom2ram(cRouterName, network);
    u_strcpy_rom2ram(cRouterPwd, password);
    WifiConnectToNetwork(network, password);
    
    u_strcpy_rom2ram(cServerIp, server.IpAddress);
    server.Port = uiServerPort;
    WifiConnectToServer(server);
    WifiDisconnectFromServer();
    
    u_strcpy_rom2ram(cDisplayIp, server.IpAddress);
    server.Port = uiDisplayPort;
    WifiConnectToServer(server);
    WifiDisconnectFromServer();
    
    DISP_Online();
    MCT_StartTimer(ucMAIN_MctCh);
    while(!bMCT_IsTimeout(ucMAIN_MctCh));
    MCT_StopTimer(ucMAIN_MctCh);
    LED_StopBlink();
    
    DISP_Main();
    while(1)
    {
        Btn_OnPressEvent( BtnGetEvent() );
    }
}
// End of file