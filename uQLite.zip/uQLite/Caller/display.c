#include <string.h>     // memset()
#include <stdio.h>      // sprintf()
#include "eldtypes.h"
#include "lcd.h"
#include "utils.h"
#include "appvars.h"

#define DISPLAY_LINE_LEN        (16)

VOID ShowWelcome(VOID)
{
    CHAR serial[DISPLAY_LINE_LEN + 1];
    
    memset(serial, 0, DISPLAY_LINE_LEN+1);
    APPVARS_GetSerialNumber(serial);
    
    LCD_CLS;
	LCD_setCursor_Pos(0, 5);
	LCD_printS("uQLite");
	LCD_setCursor_Pos(1, 0);
    LCD_printS("SN#");
    LCD_printS(serial);
}

VOID DISP_Connecting(VOID)
{
	LCD_CLS;
	LCD_setCursor_Pos(0, 1);
	LCD_printS("Please Wait...");
	LCD_setCursor_Pos(1, 1);
	LCD_printS("Connecting....");
}

VOID DISP_Online(VOID)
{
	LCD_CLS;
	LCD_setCursor_Pos(0, 5);
	LCD_printS("ONLINE");
}

VOID DISP_Offline(VOID)
{
	LCD_CLS;
	LCD_setCursor_Pos(0, 4);
	LCD_printS("OFFLINE!");
}

VOID DISP_Main(VOID)
{
	LCD_CLS;
	LCD_setCursor_Pos(1, 0);
	LCD_printS("SERVING: IDLE");
}

////////////////////////////////////////////////////////////////////////////////
// strService & strTicket must be null-terminated
////////////////////////////////////////////////////////////////////////////////
VOID ShowTicket(rom CHAR *strService, CHAR *ticketNum)
{
    UINT8 i;
    CHAR temp[DISPLAY_LINE_LEN];
    
    u_memcpy_rom2ram((rom UINT8 *)strService, (UINT8 *)temp, DISPLAY_LINE_LEN);
    LCD_setCursor_Pos(0, 0);
    for(i = 0; (i < DISPLAY_LINE_LEN) && (temp[i] != '\0'); i++)
        LCD_printC((UCHAR)temp[i]);
    
    LCD_setCursor_Pos(1, 9);
    for(i = 0; i < 4; i++)
        LCD_printC(ticketNum[i]);
}

VOID DISP_Requesting(VOID)
{
    LCD_setCursor_Pos(0, 0);
    LCD_printS("Requesting...   ");
}

VOID DISP_ClearRequesting(VOID)
{
    LCD_setCursor_Pos(0, 0);
    LCD_printS("                ");
}

VOID ShowService(rom CHAR *strService)
{
    UINT8 i;
    CHAR temp[DISPLAY_LINE_LEN];
    
    u_memcpy_rom2ram((rom UINT8 *)strService, (UINT8 *)temp, DISPLAY_LINE_LEN);
    LCD_setCursor_Pos(0, 0);
    for(i = 0; (i < DISPLAY_LINE_LEN) && (temp[i] != '\0'); i++)
        LCD_printC((UCHAR)temp[i]);
    while(i < DISPLAY_LINE_LEN)
    {
        LCD_printC(' ');
        i++;
    }
}

VOID ShowSelection(rom CHAR *strSelection, UINT8 strLen, BOOL showHeader)
{
    if(showHeader)
    {
        LCD_CLS;
        LCD_setCursor_Pos(0, 0);
        LCD_printS("Select below:");
    }
    
    LCD_setCursor_Pos(1, 0);
    while(strLen--)
    {
        if(*strSelection == 0)
            LCD_printC(' ');
        else
            LCD_printC(*strSelection++);
    }
}

VOID DISP_DeviceConfig(VOID)
{
    LCD_CLS;
    LCD_setCursor_Pos(0, 0);
    LCD_printS("Configuring");
    LCD_setCursor_Pos(1, 0);
    LCD_printS("Device...");
}

VOID DISP_SysErr(UINT16 uiErr)
{
    CHAR error[STRLEN_MAX];
    
    memset(error, 0, STRLEN_MAX);
    sprintf(error, "ERROR (%03d)", uiErr);
    
	LCD_CLS;
	LCD_setCursor_Pos(0, 4);
	LCD_printS("OFFLINE!");
    LCD_setCursor_Pos(1,3);
    LCD_printS(error);
}

// End of file