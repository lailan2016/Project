#include <ez8.h>
#include <stdlib.h>
#include <string.h>
#include "eldtypes.h"
#include "buttons.h"
#include "appvars.h"

#include "main.h"
#include "led.h"
#include "display.h"

#include "ctrans.h"
#include "utils.h"

#define BTN_USE_ONPRESS_EVT     (1)
                                        
#define BTNSTATE_IDLE           (0)
#define BTNSTATE_TRANSACTION    (1)
#define BTNSTATE_TXERSELECTION  (2)
#define BTNSTATE_DONESELECTION  (3)

UINT8 BtnState = BTNSTATE_IDLE;

////////////////////////////////////////////////////////////////////////////////
// Function Prototypes - Custom Button Routines
////////////////////////////////////////////////////////////////////////////////
VOID BtnCallEvent(VOID);
VOID BtnRecallEvent(VOID);
VOID BtnDoneEvent(VOID);
VOID BtnTxerEvent(VOID);

VOID BtnUpEvent(VOID);
VOID BtnDownEvent(VOID);
VOID BtnEnterEvent(VOID);

////////////////////////////////////////////////////////////////////////////////
// Extern References
////////////////////////////////////////////////////////////////////////////////
extern rom CHAR cRmksList[RMKSLIST_MAXNUM][STRLEN_MAX];
extern rom CHAR cSvcList[SVCLIST_MAXNUM][STRLEN_MAX];
extern rom UINT8 ucSysRmksMax;
extern rom UINT8 ucMySvcId;
extern rom UINT8 ucSysSvcMax;

////////////////////////////////////////////////////////////////////////////////
// Button Hardware Assignment :: Caller hardware label to PortA bit association
// Do not change unless hardware has physically changed
////////////////////////////////////////////////////////////////////////////////
#define BTNS_MAXNUM     (6)         // Max buttons per clicker HW design

#define SW1             (0x08)
#define SW2             (0x04)
#define SW3             (0x10)
#define SW4             (0x20)
#define SW5             (0x40)
#define SW6             (0x80)

#define SWMASK          (SW1 | SW2 | SW3 |SW4 | SW5 | SW6)

////////////////////////////////////////////////////////////////////////////////
// Button Function Groups - points to BtnFxMap row
////////////////////////////////////////////////////////////////////////////////
#define BTNFX_MAXNUM    (2)         // Max button function as of now: (=2)
                                    // if FW req'ts change, modify this value and edit associated Button Function Map
#define BTNFX_NORMAL    (0)         // Button function index in BtnFxMap for normal operation
#define BTNFX_SELECTOR  (1)         // Button function index in BtnFxMap for selection operation

////////////////////////////////////////////////////////////////////////////////
// Button Mapping :: Maps a button function to its physical location in hardware
////////////////////////////////////////////////////////////////////////////////
#define BTNFX_DISABLED  (0)         // Use this value if button is not used/disabled

// BTNFX_NORMAL
#define BTNFX1_CALL     (SW5)
#define BTNFX1_RECALL   (SW4)
#define BTNFX1_DONE     (SW3)
#define BTNFX1_TXER     (SW2)

// BTNFX_SELECTOR
#define BTNFX2_UP       (SW5)
#define BTNFX2_DOWN     (SW3)
#define BTNFX2_ENTER    (SW4)

////////////////////////////////////////////////////////////////////////////////
// Button Function Map
//  row - button function group
//  col - button assignment for each function
// NOTE: In case several buttons are pressed at the same time, only the button
//      with the highest priority will be served. Button priority is defined
//      by col; where col0 has the highest priority & col5 has the lowest priority
////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    UINT8 BtnMask;                  // button mask from port bit mapping
    VOID (*const fpBtnFx)(VOID);    // button function associated with port bit
}BtnFx; // defines which button performs what function
VOID (*const BTN_Fx[BTNFX_MAXNUM][BTNS_MAXNUM])(VOID);

BtnFx BtnFxMap[BTNFX_MAXNUM][BTNS_MAXNUM] = {
    {   // Normal Operation
        { BTNFX1_CALL,      BtnCallEvent    },
        { BTNFX1_RECALL,    BtnRecallEvent  },
        { BTNFX1_DONE,      BtnDoneEvent    },
        { BTNFX1_TXER   ,   BtnTxerEvent    },
        { BTNFX_DISABLED,   nullptr_t   },
        { BTNFX_DISABLED,   nullptr_t   }
    },
    {   // Selector Operation
        { BTNFX2_UP,        BtnUpEvent      },
        { BTNFX2_DOWN,      BtnDownEvent    },
        { BTNFX2_ENTER,     BtnEnterEvent   },
        { BTNFX_DISABLED,   nullptr_t   },
        { BTNFX_DISABLED,   nullptr_t   },
        { BTNFX_DISABLED,   nullptr_t   }
    }
};

#define BTNCHECKS_MAXCNT      (10)
UINT8 BtnStateChecks[BTNCHECKS_MAXCNT];
UINT8 BtnStateChecksIdx;
UINT8 BtnPrevState;
BOOL IsBtnBusy = TRUE;

////////////////////////////////////////////////////////////////////////////////
// Button Function Mapping Aids...
// BtnCurrFx - current button function set to follow (BTNFX_NORMAL or BTNFX_SELECTOR)
////////////////////////////////////////////////////////////////////////////////
UINT8 BtnCurrFx = 0;
UINT8 ucBTN_MaxSelCnt = 0;
UINT8 ucBTN_CurrSelDisplay = 0;
rom CHAR (*cBTN_CurrSelList)[STRLEN_MAX];

////////////////////////////////////////////////////////////////////////////////
// Module initialization....
////////////////////////////////////////////////////////////////////////////////
VOID BtnInit(VOID)
{
    UINT8 i = 0;
    
    PADD |= SWMASK;             // GPIO init for buttons
    BtnPrevState = SWMASK;      // Initial button states = RELEASED (1)
    BtnStateChecksIdx = 0;
    for(i = 0; i < BTNCHECKS_MAXCNT; i++)
        BtnStateChecks[i] = SWMASK;
    
    BtnCurrFx = BTNFX_NORMAL;   // Initial button function = NORMAL OPERATION
	IsBtnBusy = FALSE;
}

////////////////////////////////////////////////////////////////////////////////
// Checks for current button status
////////////////////////////////////////////////////////////////////////////////
VOID BtnScan(VOID)
{
    UINT8 temp = 0;
	
    if(IsBtnBusy)
		return;
    
    temp = PAIN & SWMASK;
    BtnStateChecks[BtnStateChecksIdx++] = temp;
    if(BtnStateChecksIdx >= BTNCHECKS_MAXCNT)
        BtnStateChecksIdx = 0;
}

////////////////////////////////////////////////////////////////////////////////
// Normalizes buton state/s
////////////////////////////////////////////////////////////////////////////////
UINT8 BtnNormalize(VOID)
{
    UINT8 i;
    UINT8 keyState = SWMASK;    // summary of button state/s
    
    // normalize button states
    for(i = 0; i < BTNCHECKS_MAXCNT; i++)
        keyState = keyState & BtnStateChecks[i];
    
    return keyState;
}

////////////////////////////////////////////////////////////////////////////////
// Determines if a button press event occurred
// returns the button with event
////////////////////////////////////////////////////////////////////////////////
UINT8 BtnGetEvent(VOID)
{
    UINT8 i;
    UINT8 keyEvent = 0;         // determines a button event
    UINT8 keyState = BtnNormalize();
    
    // identify if an event occurs
    for(i = 0x01; i > 0; i <<= 1)
    {
        if( ((BtnPrevState & i) && !(keyState & i)) )
        keyEvent |= i;
    }
    
    BtnPrevState = keyState;
    return keyEvent;
}

////////////////////////////////////////////////////////////////////////////////
// Determines if a button press event occurred
////////////////////////////////////////////////////////////////////////////////
BOOL IsBtnPressed(VOID)
{
    return (BtnNormalize() != SWMASK);
}

////////////////////////////////////////////////////////////////////////////////
// Executes the associated function as defined by btnEvent
////////////////////////////////////////////////////////////////////////////////
VOID Btn_OnPressEvent(UINT8 btnEvent)
{
    UINT8 col = 0;
    
    if(!btnEvent || IsBtnBusy)
        return;
    
    IsBtnBusy = TRUE;
    LED_On();
    
    for(col = 0; col < BTNS_MAXNUM; col++)
    {
        if( (btnEvent & BtnFxMap[BtnCurrFx][col].BtnMask) &&
            (BtnFxMap[BtnCurrFx][col].fpBtnFx != nullptr_t) )
        {
                BtnFxMap[BtnCurrFx][col].fpBtnFx();
                break;
        }
    }
    
    BtnPrevState &= ~btnEvent;
    IsBtnBusy = FALSE;
    LED_Off();
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
// Button Routines for BTNFX_NORMAL
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
VOID BtnCallEvent(VOID)
{
    UINT8 svcidx = 0;
    CHAR ticket[4] = "0000";
    
    if(BtnState != BTNSTATE_IDLE)
        return;
    
    DISP_Requesting();
    if( !ExecuteCall(ticket) )
    {
        DISP_ClearRequesting();
    }
    else
    {
        if( (ticket[0] != '0') || (ticket[1] != '0') ||
        (ticket[2] != '0') || (ticket[3] != '0') )
        {   
            DISP_ClearRequesting();
            ShowTicket(&cSvcList[ucMySvcId], ticket);
            ExecRecall();
            BtnState = BTNSTATE_TRANSACTION;
        }
        else
        {
            DISP_ClearRequesting();
        }
    }
}

VOID BtnRecallEvent(VOID)
{
    if(BtnState != BTNSTATE_TRANSACTION)
        return;
    
    DISP_Requesting();
    ExecRecall();
    ShowService(&cSvcList[ucMySvcId]);
}

VOID BtnDoneEvent(VOID)
{
    if(BtnState != BTNSTATE_TRANSACTION)
        return;
    
    BtnCurrFx = BTNFX_SELECTOR;
    ucBTN_CurrSelDisplay = 0;
    cBTN_CurrSelList = cRmksList;
    ucBTN_MaxSelCnt = ucSysRmksMax;
    ShowSelection(cBTN_CurrSelList[ucBTN_CurrSelDisplay], STRLEN_MAX, TRUE);
    
    BtnState = BTNSTATE_DONESELECTION;
}

VOID BtnTxerEvent(VOID)
{
    if(BtnState != BTNSTATE_TRANSACTION)
        return;
    
    BtnCurrFx = BTNFX_SELECTOR;
    ucBTN_CurrSelDisplay = 0;
    cBTN_CurrSelList = cSvcList;
    ucBTN_MaxSelCnt = ucSysSvcMax;
        
    // Exclude my service from selection
    if(ucBTN_CurrSelDisplay == ucMySvcId)
        ucBTN_CurrSelDisplay++;
    ShowSelection(cBTN_CurrSelList[ucBTN_CurrSelDisplay], STRLEN_MAX, TRUE);
    
    BtnState = BTNSTATE_TXERSELECTION;
}

////////////////////////////////////////////////////////////////////////////////
// Button Routines for BTNFX_SELECTOR
////////////////////////////////////////////////////////////////////////////////
VOID BtnUpEvent(VOID)
{
    if( !(BtnState == BTNSTATE_TXERSELECTION) &&
        !(BtnState == BTNSTATE_DONESELECTION) )
        return;
    
    // Scroll Up
    if(ucBTN_CurrSelDisplay == 0)
            ucBTN_CurrSelDisplay = ucBTN_MaxSelCnt - 1;
    else
        ucBTN_CurrSelDisplay--;
    
    if(BtnState == BTNSTATE_TXERSELECTION)
    {   // Exclude my service from selection
        if(ucBTN_CurrSelDisplay == ucMySvcId)
        {
            if(ucBTN_CurrSelDisplay == 0)
                ucBTN_CurrSelDisplay = ucBTN_MaxSelCnt - 1;
            else
                ucBTN_CurrSelDisplay--;
        }
    }
    
    ShowSelection(cBTN_CurrSelList[ucBTN_CurrSelDisplay], STRLEN_MAX, FALSE);
}

VOID BtnDownEvent(VOID)
{
    if( !(BtnState == BTNSTATE_TXERSELECTION) &&
        !(BtnState == BTNSTATE_DONESELECTION) )
        return;
    
    // Scroll Down
    ucBTN_CurrSelDisplay++;
    if(ucBTN_CurrSelDisplay >= ucBTN_MaxSelCnt)
        ucBTN_CurrSelDisplay = 0;
    
    if(BtnState == BTNSTATE_TXERSELECTION)
    {   // Exclude my service from selection
        if(ucBTN_CurrSelDisplay == ucMySvcId)
        {
            ucBTN_CurrSelDisplay++;
            if(ucBTN_CurrSelDisplay >= ucBTN_MaxSelCnt)
                ucBTN_CurrSelDisplay = 0;
        }
    }
    
    ShowSelection(cBTN_CurrSelList[ucBTN_CurrSelDisplay], STRLEN_MAX, FALSE);
}

VOID BtnEnterEvent(VOID)
{
    if( !(BtnState == BTNSTATE_TXERSELECTION) &&
        !(BtnState == BTNSTATE_DONESELECTION) )
        return;
    
    DISP_Requesting();
    if(BtnState == BTNSTATE_TXERSELECTION)
    {   // Execute transfer transaction
        ExecTxer(ucBTN_CurrSelDisplay);
    }
    
    if(BtnState == BTNSTATE_DONESELECTION)
    {   // Execute done transaction
        ExecDone(ucBTN_CurrSelDisplay);
    }
    DISP_ClearRequesting();
    BtnCurrFx = BTNFX_NORMAL;
    BtnState = BTNSTATE_IDLE;
    DISP_Main();
}
// End of file