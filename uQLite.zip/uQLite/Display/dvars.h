#ifndef __CVARS_H__
#define __CVARS_H__

#include "appvars.h"

#define MY_DVC_CODE         DISPLAY_DVC_CODE
#define APPVARS_MAXVARS     (4)

//extern rom UINT8 ucReserved1[368];
extern rom CHAR cRouterName[ROUTER_LEN];
extern rom CHAR cRouterPwd[ROUTER_LEN];
extern rom CHAR cServerIp[STRLEN_MAX];
//extern rom UINT8 ucReserved2[65];
extern rom UINT8 ucSysSvcMax;
//extern rom UINT8 ucReserved3;
extern rom UINT16 uiServerPort;
//extern rom UINT8 ucReserved4[11];
//extern rom UINT8 uiSrvrIdRsv[5];
extern rom CHAR cSrvrDvcHdr;
extern rom UINT16 uiSrvrDvcId;
//extern rom UINT8 uiMyIdRsv[5];
extern rom CHAR cMyDvcHdr;
extern rom UINT16 uiMyDvcId;

#endif // __CVARS_H__