#ifndef __CTRANS_H__
#define __CTRANS_H__

typedef enum
{
    TRANS_IDLE,     // nothing in process
    TRANS_CALL,
    TRANS_RECALL,
    TRANS_SKIP,
    TRANS_DONE
}tCTRANS_ID;

BOOL bCTRANS_SetNewRqst(tCTRANS_ID tTransId);
UINT16 uiCTRANS_ExecuteRqst(UINT8 ucRmksId);


#endif // __CTRANS_H__
// End of file