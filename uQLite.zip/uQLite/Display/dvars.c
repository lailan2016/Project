#include "eldtypes.h"
#include "dvars.h"

CHAR cFirmwareVersion[] = FIRMWARE_VERSION;

// Flash Offset Map
tAPPVARS_Map APPVARS_Map[APPVARS_MAXVARS] = {
	{ "ssid\0",	    0x0170,     VARTYPE_STRING, ROUTER_LEN },
	{ "spwd\0", 	0x0180,     VARTYPE_STRING, ROUTER_LEN },
	{ "kip\0", 	    0x0190,     VARTYPE_STRING, STRLEN_MAX },
	{ "kport\0",    0x01E3,     VARTYPE_SHORT,  2 }
};

rom UINT8 ucReserved1[368] _At APPVARS_STA_ADDR;

rom CHAR cRouterName[ROUTER_LEN] _At ... = "uQLite\0";
rom CHAR cRouterPwd[ROUTER_LEN] _At ... = "ELD2015!\0";
rom CHAR cServerIp[STRLEN_MAX] _At ... = "192.168.0.100\0";

rom UINT8 ucReserved2[67] _At ...;

rom UINT16 uiServerPort _At ... = 3334;

rom UINT8 ucReserved4[11] _At ...;

rom UINT8 ucSrvrIdRsv[5] _At ... = {0, 0, 0, 0, 0};
rom CHAR cSrvrDvcHdr _At ... = KIOSK_DVC_CODE;
rom UINT16 uiSrvrDvcId _At ... = 2;

rom UINT8 uiMyIdRsv[5] _At ... = {0, 0, 0, 0, 0};
rom CHAR cMyDvcHdr _At ... = MY_DVC_CODE;
rom UINT16 uiMyDvcId _At ... = 1001;

// End of file