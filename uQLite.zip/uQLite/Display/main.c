#include <ez8.h>
#include <string.h>
#include "eldtypes.h"
#include "z8mct.h"
#include "main.h"
#include "esp11.h"
#include "appvars.h"
#include "dvars.h"
#include "utils.h"

#include "spi.h"
#include "max7219.h"
#include "tcp.h"
#include "esp11.h"
#include "dvars.h"

////////////////////////////////////////////////////////////////////////////////
// Designed and Tested for Z8F6481
////////////////////////////////////////////////////////////////////////////////

// Buzzer
#define INIT_BUZZER()       (PCDD  &=~(1<<0))
#define INIT_HDE()          (PCHDE |= (1<<0))
#define BUZZER_LOW()		(PCOUT &=~(1<<0))
#define BUZZER_HIGH()       (PCOUT |= (1<<0))

UINT8 ucBUZ_MctCh = 0;
UINT16 uiResetCount = 0;

VOID Buzzer (VOID)
{
	BUZZER_HIGH();
	MCT_StartTimer(ucBUZ_MctCh);            // check if a few NOPs can do the trick....
    while(!bMCT_IsTimeout(ucBUZ_MctCh));   
    MCT_StopTimer(ucBUZ_MctCh);            
	BUZZER_LOW();
}							   

VOID IntervalRoutine(VOID)
{
    Max7219DisplayBlink();
}

CHAR ResponseMsg[RESPMSG_LEN+1];        // plus 1 to account for null-termination

////////////////////////////////////////////////////////////////////////////////
VOID CreateResponse(CHAR toDvcHdr, UINT16 toDvcId, UINT8 ucSvcIdx, UINT16 uiTicketNum)
{
    CHAR *msg;
    
    memset(ResponseMsg, 0, RESPMSG_LEN);
    msg = ResponseMsg;
    
    *msg++ = TCP_PROT_SOF;
    
    *msg++ = MY_DVC_CODE;
    u_itoa(msg, TCP_DVCID_LEN - 1, uiMyDvcId);
    msg += TCP_DVCID_LEN - 1;
    *msg++ = TCP_PROT_SEPARATOR;
    
    *msg++ = toDvcHdr;
    u_itoa(msg, TCP_DVCID_LEN - 1, toDvcId);
    msg += TCP_DVCID_LEN - 1;
    *msg++ = TCP_PROT_SEPARATOR;
    
    u_itoa(msg, TCP_SVCIDX_LEN, ucSvcIdx);
    msg += TCP_SVCIDX_LEN;
    *msg++ = TCP_PROT_SEPARATOR;
    
    u_itoa(msg, TCP_TKTNUM_LEN, uiTicketNum);
    msg += TCP_TKTNUM_LEN;
    
    *msg++ = TCP_PROT_EOF;
    *msg = 0;
}

BOOL ParseRequest(CHAR *strMsg, TcpRequest *tRqst)
{
    if(*strMsg++ == TCP_PROT_SOF)
    {
        tRqst->FromDeviceHeader = *strMsg++;
        tRqst->FromDeviceId = u_atoi(strMsg, TCP_DVCID_LEN - 1);
        strMsg += TCP_DVCID_LEN;
        
        tRqst->ToDeviceHeader = *strMsg++;
        tRqst->ToDeviceId = u_atoi(strMsg, TCP_DVCID_LEN - 1);
        strMsg += TCP_DVCID_LEN;
        
        tRqst->RequestId = *strMsg++;
        strMsg++;   
        
        u_memcpy((UINT8 *)strMsg, (UINT8 *)tRqst->TicketNumber, TCP_TKTNUM_LEN);
        strMsg += TCP_TKTNUM_LEN + 1;
        
        tRqst->Remarks = u_atoi(strMsg, TCP_RMKS_LEN);
        strMsg += TCP_RMKS_LEN;
        
        // verify response message
        if( (tRqst->ToDeviceHeader == MY_DVC_CODE) &&
            (tRqst->ToDeviceId == uiMyDvcId) )
        {
            return TRUE;
        }
    }
    
    return FALSE;
}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
// Error Handler Routines
////////////////////////////////////////////////////////////////////////////////
VOID OnSysError(UINT16 err, CHAR *acStr)
{
    Max7219DisplayError(err);
    while(1);       // instead of reset...
}

// Error Code: 001
VOID WifiInitError(VOID)
{
    OnSysError(1, "Wifi Init Error");
}

// Error Code: 002
VOID NoNetworkError(VOID)
{
    OnSysError(2, "Network Error");
}

// Error Code: 003
VOID ServerModeError(VOID)
{
    OnSysError(3, "Cannot Start Server");
}

// Error Code: 004
VOID NoMemoryError(VOID)
{
    OnSysError(4, "Low Memory");
}

// Error Code: 005
VOID NoSdCardError(VOID)
{
    OnSysError(5, "No SD Card Found");
}

// Error Code: 006
VOID FileRwError(VOID)
{
    OnSysError(6, "File RW Error");
}

// Error Code: 007
VOID NoServerFoundError(VOID)
{
    // retry connecting to server
    OnSysError(7, "No Server Error");
}

// Error Code: 008
VOID WifiResetError(VOID)
{
    OnSysError(8, "Wifi Reset");
}

// Error Code: 009
VOID NoWifiError(VOID)
{
    OnSysError(9, "No Wifi Module");
}

BOOL ProcessTicketRqst(CHAR *acValue)
{
    CHAR rqstMsg[RQSTMSG_LEN];
    UINT8 linkId = 0;
    TcpRequest rqst;
    
    if( WifiGetString(rqstMsg, &linkId) )
    {
        if( ParseRequest(rqstMsg, &rqst) )
        {
            CreateResponse(rqst.FromDeviceHeader, rqst.FromDeviceId, 0, 0);
            WifiSendString(ResponseMsg, RESPMSG_LEN, linkId);
            
            if(rqst.RequestId == TCP_RQSTID_DISPLAY)
            {
                // disregard first char in acRemarks (we expect it's always '0')
                // this is the window number
                acValue[0] = rqst.Remarks + '0';
                
                // disregard first char in acTicketNum (we can only display 3 digits)
                u_memcpy((UINT8 *)&rqst.TicketNumber[1], (UINT8 *)&acValue[1], TCP_TKTNUM_LEN - 1);
                return TRUE;
            }
            else
            {
                // set acValue to all zero
                memset((UINT8 *)acValue, MAX7219_DEFAULT, MAX7219_ROWLEN);
            }
            
            
        }
    }
    
    return FALSE;
}

VOID AppEntry(VOID)
{
	UINT8   idx = 0;
    BOOL    valueOk = FALSE;
    CHAR network[ROUTER_LEN+1], password[ROUTER_LEN+1];
    
    // [0]:counter [1]:digit2 [2]:digit1 [3]:digit0
    CHAR   aValue[MAX7219_ROWLEN];  
    
	ucBUZ_MctCh = MCT_AddTimer(TIMEOUT_MAIN);
    uiResetCount = 0;
		
    INIT_BUZZER();
	BUZZER_LOW();
    
	SpiInit();                                // Initialize SPI
	Max7219Init();
    
	// Display
	memset(aValue, MAX7219_START, MAX7219_ROWLEN);
	Max7219Display(aValue, FALSE);              // - ---
	Max7219Display(aValue, FALSE);              // - ---

    WifiInit();
    u_strcpy_rom2ram(cRouterName, network);
    u_strcpy_rom2ram(cRouterPwd, password);
    WifiConnectToNetwork(network, password);
    
    // Display 
    memset(aValue, MAX7219_DEFAULT, MAX7219_ROWLEN);
    Buzzer();
	Max7219Display(aValue, FALSE);       // 0 000
	Max7219Display(aValue, FALSE);       // 0 000
    
//    memset(aValue, MAX7219_DEFAULT, MAX7219_ROWLEN);
    WifiStartListen(uiServerPort);
	while(1)
    {
        if( ProcessTicketRqst(aValue) )
        {
            // aValue should have at least one non-zero digit
            for(idx = 0; idx < MAX7219_ROWLEN; idx++)
            {
                if(aValue[idx] != MAX7219_DEFAULT)   // we found one non-zero digit
                {
                    valueOk = TRUE;
                    break;
                }
            }
            
            if(valueOk)
            {
                valueOk = FALSE;
                    
                Buzzer();
                Max7219Display(aValue, TRUE);
                memset(aValue, MAX7219_DEFAULT, MAX7219_ROWLEN);
            }
        }
    }
}
// End of file