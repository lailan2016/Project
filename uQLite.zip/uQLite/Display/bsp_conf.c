#include <ez8.h>
#include "eldtypes.h"
#include "bsp_conf.h"
#include "z8mct.h"

#define BSP_MCT_MAXCHANNELS     (10)
#define BSP_MCT_INTERVAL        (5)                     // in msec
#define BSP_MCT_PRIORITY        (INTPRIORITY_HIGH)
#define BSP_MCT_PRESCALE        (MCT_PRESCALE_128)

VOID IntervalRoutine(VOID);

stMCTimers stMCT_Timers[BSP_MCT_MAXCHANNELS];
stMCTConfig _gMCT_Config = {
    BSP_MCT_MAXCHANNELS, BSP_MCT_INTERVAL, BSP_MCT_PRESCALE, BSP_MCT_PRIORITY, IntervalRoutine
};

#include "z8uart.h"
#define UART_NUMCHANNELS    (2)
VOID WIFI_TxHdlr(VOID);
VOID WIFI_RxHdlr(UINT8 data); 

UINT8 _gUART_NumChannels = UART_NUMCHANNELS;
stUARTConfig _gUART_Config[UART_NUMCHANNELS] = {
    { BAUD_115200,    NOPARITY,   STOP_1, INTPRIORITY_HIGH,       WIFI_RxHdlr,    WIFI_TxHdlr },
    { BAUD_115200,    NOPARITY,   STOP_1, INTPRIORITY_HIGH,    nullptr_t,        nullptr_t}
};

#include "z8rtc.h"
stRTCConfig _gRTC_Config = { RTC_PRESCALE_1, RTC_FREQ_32kHz, RTC_CLK_SYSCLK };


extern VOID AppEntry(VOID);

VOID main(VOID)
{   
    UINT16 delay = 0xFFFF;
    while(delay--);
    
    DI();
	
    do
    {
        CLKCTL0 = 0xE7;
		CLKCTL0 = 0x18;
    }while(!(CLKCTL0 & 0x80));
      
    CLKCTL2 = 0x09;             // select HFXO
    while(!(CLKCTL2 & 0x80));   // wait until ready

    CLKCTLA = 0x2F;             // configure PLL
    CLKCTLB = 0x34;
    CLKCTLC = 0x01;             // select HFXO for PLL source
    while(!(CLKCTLC & 0x80));   // wait for PLL to be ready
        
    CLKCTL0 = 0x8B;
        
    while( (CLKCTL0 & 0x07) != 0x03 );
    
    CLKCTL1 |= 0x01;              
    CLKCTL5 = 0x05;
    CLKCTL4 = 0x00;               
    CLKCTL3 = 0x7A;               
    while(!(CLKCTL5 & 0x10));       
    CLKCTL0 &= ~0x80;
    EI();
    
    MCT_Init();
    UART_Init(UART0);
    
    AppEntry();
}

// End of file